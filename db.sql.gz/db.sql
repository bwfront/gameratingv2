-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB-1:10.4.32+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) NOT NULL DEFAULT '',
  `title` varchar(120) NOT NULL DEFAULT '',
  `widgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1710177434,1710177434,1,0,0,0,0,'8b81f727a29f0437dcb0ce834bd8870c73c9af2c','My dashboard','{\"616590b2fa304982564b7b8d50207d10538140f2\":{\"identifier\":\"t3information\"},\"db448b93692e1d3382e51d485b30914ea68c8952\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  `mfa_providers` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES ('5e84f9fd1b19645796a73b4b13ead8eaed8e7340c4977fc71675ebc1f2b02207','[DISABLED]',1,1710346474,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"be606bd982a30a6672e035b58440c9e179819d398822faa4bb8dca9e0284b30b\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `category_perms` longtext DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1710177427,1710177427,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$STRLZkxoTzBHSWRDaFlLNA$6ZNNVkuE1bHiPYu83KBXD4OTwS9DqG6musbREvk/OxM',1,NULL,'default','',NULL,0,'',NULL,'','a:14:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:12:{s:28:\"dashboard/current_dashboard/\";s:40:\"8b81f727a29f0437dcb0ce834bd8870c73c9af2c\";s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";s:19:\"constant_editor_cat\";N;}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:16:\"extensionbuilder\";a:1:{s:9:\"firstTime\";i:0;}s:10:\"FormEngine\";a:2:{i:0;a:2:{s:32:\"8244765b032541eb3340d6c094537eb4\";a:4:{i:0;s:12:\"Helldivers 2\";i:1;a:5:{s:4:\"edit\";a:1:{s:30:\"tx_gameskey_domain_model_games\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_gameskey_domain_model_games%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:30:\"tx_gameskey_domain_model_games\";s:3:\"uid\";i:6;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"822e58c5987e092061b9c55517b67b96\";a:4:{i:0;s:21:\"Need For Speed Carbon\";i:1;a:5:{s:4:\"edit\";a:1:{s:30:\"tx_gameskey_domain_model_games\";a:1:{i:8;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_gameskey_domain_model_games%5D%5B8%5D=edit\";i:3;a:5:{s:5:\"table\";s:30:\"tx_gameskey_domain_model_games\";s:3:\"uid\";i:8;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"822e58c5987e092061b9c55517b67b96\";}s:16:\"opendocs::recent\";a:7:{s:32:\"822e58c5987e092061b9c55517b67b96\";a:4:{i:0;s:21:\"Need For Speed Carbon\";i:1;a:5:{s:4:\"edit\";a:1:{s:30:\"tx_gameskey_domain_model_games\";a:1:{i:8;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_gameskey_domain_model_games%5D%5B8%5D=edit\";i:3;a:5:{s:5:\"table\";s:30:\"tx_gameskey_domain_model_games\";s:3:\"uid\";i:8;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"a56c49ec3ad304728447ab7c002f8c0a\";a:4:{i:0;s:9:\"Minecraft\";i:1;a:5:{s:4:\"edit\";a:1:{s:30:\"tx_gameskey_domain_model_games\";a:1:{i:7;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_gameskey_domain_model_games%5D%5B7%5D=edit\";i:3;a:5:{s:5:\"table\";s:30:\"tx_gameskey_domain_model_games\";s:3:\"uid\";i:7;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"68095246654d4c2321f1e290b06ebac6\";a:4:{i:0;s:5:\"GTA V\";i:1;a:5:{s:4:\"edit\";a:1:{s:30:\"tx_gameskey_domain_model_games\";a:1:{i:5;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_gameskey_domain_model_games%5D%5B5%5D=edit\";i:3;a:5:{s:5:\"table\";s:30:\"tx_gameskey_domain_model_games\";s:3:\"uid\";i:5;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"d0338744e0d719a22f923f76afb8ddee\";a:4:{i:0;s:4:\"GTA5\";i:1;a:5:{s:4:\"edit\";a:1:{s:30:\"tx_gameskey_domain_model_games\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_gameskey_domain_model_games%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:30:\"tx_gameskey_domain_model_games\";s:3:\"uid\";i:4;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"67b5a08b0cad5a7b7813fc292df3d015\";a:4:{i:0;s:4:\"GTA5\";i:1;a:5:{s:4:\"edit\";a:1:{s:30:\"tx_gameskey_domain_model_games\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_gameskey_domain_model_games%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:30:\"tx_gameskey_domain_model_games\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"c312013d83c1a6ad7fec8b36a37ba3c8\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:4:{i:0;s:4:\"Home\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:6:\"web_ts\";a:6:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:8:\"language\";N;s:19:\"constant_editor_cat\";s:7:\"content\";s:15:\"ts_browser_type\";s:5:\"const\";s:16:\"ts_browser_const\";s:1:\"0\";s:23:\"ts_browser_showComments\";s:1:\"1\";}s:8:\"web_list\";a:3:{s:8:\"function\";N;s:8:\"language\";N;s:19:\"constant_editor_cat\";N;}s:8:\"web_info\";a:3:{s:8:\"function\";s:48:\"TYPO3\\CMS\\Belog\\Module\\BackendLogModuleBootstrap\";s:8:\"language\";N;s:19:\"constant_editor_cat\";N;}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:9:\"1:/image/\";}s:9:\"file_list\";a:3:{s:8:\"function\";N;s:8:\"language\";N;s:19:\"constant_editor_cat\";N;}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:25:\"resizeTextareas_MaxHeight\";i:500;s:4:\"lang\";s:7:\"default\";s:19:\"firstLoginTimeStamp\";i:1710177433;s:15:\"moduleSessionID\";a:12:{s:28:\"dashboard/current_dashboard/\";s:40:\"edc10d3e54f3f6ecf34d883aa74c7e20d7fa2737\";s:10:\"web_layout\";s:40:\"edc10d3e54f3f6ecf34d883aa74c7e20d7fa2737\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"7f7bfc928142fd8dd2be0dbab8942af962b89a40\";s:16:\"extensionbuilder\";s:40:\"7d378bfcc788034632b0cc73f51af3504d8f9a57\";s:10:\"FormEngine\";s:40:\"7f7bfc928142fd8dd2be0dbab8942af962b89a40\";s:16:\"opendocs::recent\";s:40:\"7f7bfc928142fd8dd2be0dbab8942af962b89a40\";s:6:\"web_ts\";s:40:\"edc10d3e54f3f6ecf34d883aa74c7e20d7fa2737\";s:8:\"web_list\";s:40:\"edc10d3e54f3f6ecf34d883aa74c7e20d7fa2737\";s:8:\"web_info\";s:40:\"edc10d3e54f3f6ecf34d883aa74c7e20d7fa2737\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"7f7bfc928142fd8dd2be0dbab8942af962b89a40\";s:16:\"browse_links.php\";s:40:\"7f7bfc928142fd8dd2be0dbab8942af962b89a40\";s:9:\"file_list\";s:40:\"7d378bfcc788034632b0cc73f51af3504d8f9a57\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:1:{s:3:\"0_1\";s:1:\"1\";}}}}s:10:\"modulemenu\";s:27:\"{\"system\":true,\"site\":true}\";s:17:\"systeminformation\";s:45:\"{\"system_BelogLog\":{\"lastAccess\":1710331184}}\";s:10:\"inlineView\";s:311:\"{\"tx_gameskey_domain_model_games\":{\"NEW65f02458ec676447722640\":{\"sys_file_reference\":[1]},\"NEW65f06963b4e8d957158719\":{\"sys_file_reference\":[2]},\"NEW65f06bae73e8e099304581\":{\"sys_file_reference\":[3]},\"NEW65f1940ba8460460618983\":{\"sys_file_reference\":[4]},\"NEW65f194cc6ce5a366290866\":{\"sys_file_reference\":[5]}}}\";}',NULL,NULL,1,NULL,1710314633,0,NULL,NULL,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
INSERT INTO `cache_hash` VALUES (1,'3697f667c6ada1e0ea4b26eab03b6a29',2145909600,'a:3:{s:8:\"options.\";a:8:{s:15:\"enableBookmarks\";s:1:\"1\";s:10:\"file_list.\";a:3:{s:23:\"enableDisplayThumbnails\";s:10:\"selectable\";s:15:\"enableClipBoard\";s:10:\"selectable\";s:10:\"thumbnail.\";a:2:{s:5:\"width\";s:2:\"64\";s:6:\"height\";s:2:\"64\";}}s:9:\"pageTree.\";a:1:{s:31:\"doktypesToShowInNewPageDragArea\";s:21:\"1,6,4,7,3,254,255,199\";}s:12:\"contextMenu.\";a:1:{s:6:\"table.\";a:3:{s:6:\"pages.\";a:2:{s:12:\"disableItems\";s:0:\"\";s:5:\"tree.\";a:1:{s:12:\"disableItems\";s:0:\"\";}}s:9:\"sys_file.\";a:2:{s:12:\"disableItems\";s:0:\"\";s:5:\"tree.\";a:1:{s:12:\"disableItems\";s:0:\"\";}}s:15:\"sys_filemounts.\";a:2:{s:12:\"disableItems\";s:0:\"\";s:5:\"tree.\";a:1:{s:12:\"disableItems\";s:0:\"\";}}}}s:11:\"saveDocView\";s:1:\"1\";s:10:\"saveDocNew\";s:1:\"1\";s:11:\"saveDocNew.\";a:3:{s:5:\"pages\";s:1:\"0\";s:8:\"sys_file\";s:1:\"0\";s:17:\"sys_file_metadata\";s:1:\"0\";}s:14:\"disableDelete.\";a:1:{s:8:\"sys_file\";s:1:\"1\";}}s:9:\"admPanel.\";a:1:{s:7:\"enable.\";a:1:{s:3:\"all\";s:1:\"1\";}}s:12:\"TCAdefaults.\";a:1:{s:9:\"sys_note.\";a:2:{s:6:\"author\";s:0:\"\";s:5:\"email\";s:0:\"\";}}}'),(2,'0eba7ec1b1917d151fccda947fc067e6',2145909600,'a:2:{s:9:\"constants\";a:2:{s:7:\"styles.\";a:2:{s:8:\"content.\";a:7:{s:10:\"loginform.\";a:21:{s:3:\"pid\";s:1:\"0\";s:9:\"recursive\";s:1:\"0\";s:22:\"showForgotPasswordLink\";s:1:\"0\";s:18:\"showForgotPassword\";s:1:\"0\";s:14:\"showPermaLogin\";s:1:\"0\";s:24:\"showLogoutFormAfterLogin\";s:1:\"0\";s:9:\"emailFrom\";s:0:\"\";s:13:\"emailFromName\";s:0:\"\";s:12:\"replyToEmail\";s:0:\"\";s:10:\"dateFormat\";s:9:\"Y-m-d H:i\";s:6:\"email.\";a:4:{s:14:\"layoutRootPath\";s:0:\"\";s:16:\"templateRootPath\";s:46:\"EXT:felogin/Resources/Private/Email/Templates/\";s:15:\"partialRootPath\";s:0:\"\";s:12:\"templateName\";s:16:\"PasswordRecovery\";}s:12:\"redirectMode\";s:0:\"\";s:19:\"redirectFirstMethod\";s:1:\"0\";s:17:\"redirectPageLogin\";s:1:\"0\";s:22:\"redirectPageLoginError\";s:1:\"0\";s:18:\"redirectPageLogout\";s:1:\"0\";s:15:\"redirectDisable\";s:1:\"0\";s:23:\"forgotLinkHashValidTime\";s:2:\"12\";s:20:\"newPasswordMinLength\";s:1:\"6\";s:7:\"domains\";s:0:\"\";s:43:\"exposeNonexistentUserInForgotPasswordDialog\";s:1:\"0\";}s:17:\"defaultHeaderType\";s:1:\"2\";s:9:\"shortcut.\";a:1:{s:6:\"tables\";s:10:\"tt_content\";}s:9:\"allowTags\";s:392:\"a, abbr, acronym, address, article, aside, b, bdo, big, blockquote, br, caption, center, cite, code, col, colgroup, dd, del, dfn, dl, div, dt, em, font, footer, header, h1, h2, h3, h4, h5, h6, hr, i, img, ins, kbd, label, li, link, meta, nav, ol, p, pre, q, s, samp, sdfield, section, small, span, strike, strong, style, sub, sup, table, thead, tbody, tfoot, td, th, tr, title, tt, u, ul, var\";s:6:\"image.\";a:2:{s:11:\"lazyLoading\";s:4:\"lazy\";s:13:\"imageDecoding\";s:0:\"\";}s:10:\"textmedia.\";a:9:{s:4:\"maxW\";s:3:\"600\";s:10:\"maxWInText\";s:3:\"300\";s:13:\"columnSpacing\";s:2:\"10\";s:10:\"rowSpacing\";s:2:\"10\";s:10:\"textMargin\";s:2:\"10\";s:11:\"borderColor\";s:7:\"#000000\";s:11:\"borderWidth\";s:1:\"2\";s:13:\"borderPadding\";s:1:\"0\";s:9:\"linkWrap.\";a:6:{s:5:\"width\";s:4:\"800m\";s:6:\"height\";s:4:\"600m\";s:9:\"newWindow\";s:1:\"0\";s:15:\"lightboxEnabled\";s:1:\"0\";s:16:\"lightboxCssClass\";s:8:\"lightbox\";s:20:\"lightboxRelAttribute\";s:21:\"lightbox[{field:uid}]\";}}s:6:\"links.\";a:2:{s:9:\"extTarget\";s:6:\"_blank\";s:4:\"keep\";s:4:\"path\";}}s:10:\"templates.\";a:3:{s:16:\"templateRootPath\";s:0:\"\";s:15:\"partialRootPath\";s:0:\"\";s:14:\"layoutRootPath\";s:0:\"\";}}s:7:\"plugin.\";a:2:{s:17:\"tx_felogin_login.\";a:1:{s:5:\"view.\";a:3:{s:16:\"templateRootPath\";s:0:\"\";s:15:\"partialRootPath\";s:0:\"\";s:14:\"layoutRootPath\";s:0:\"\";}}s:26:\"tx_gameskey_gamesfrontkey.\";a:2:{s:5:\"view.\";a:3:{s:16:\"templateRootPath\";s:41:\"EXT:gameskey/Resources/Private/Templates/\";s:15:\"partialRootPath\";s:40:\"EXT:gameskey/Resources/Private/Partials/\";s:14:\"layoutRootPath\";s:39:\"EXT:gameskey/Resources/Private/Layouts/\";}s:12:\"persistence.\";a:1:{s:10:\"storagePid\";s:1:\"3\";}}}}s:5:\"setup\";a:10:{s:7:\"config.\";a:2:{s:19:\"pageTitleProviders.\";a:2:{s:7:\"record.\";a:1:{s:8:\"provider\";s:48:\"TYPO3\\CMS\\Core\\PageTitle\\RecordPageTitleProvider\";}s:4:\"seo.\";a:2:{s:8:\"provider\";s:49:\"TYPO3\\CMS\\Seo\\PageTitle\\SeoTitlePageTitleProvider\";s:6:\"before\";s:6:\"record\";}}s:11:\"tx_extbase.\";a:3:{s:4:\"mvc.\";a:1:{s:48:\"throwPageNotFoundExceptionIfActionCantBeResolved\";s:1:\"0\";}s:12:\"persistence.\";a:2:{s:28:\"enableAutomaticCacheClearing\";s:1:\"1\";s:20:\"updateReferenceIndex\";s:1:\"0\";}s:9:\"features.\";a:2:{s:20:\"skipDefaultArguments\";s:1:\"0\";s:25:\"ignoreAllEnableFieldsInBe\";s:1:\"0\";}}}s:7:\"styles.\";a:1:{s:8:\"content.\";a:2:{s:3:\"get\";s:7:\"CONTENT\";s:4:\"get.\";a:2:{s:5:\"table\";s:10:\"tt_content\";s:7:\"select.\";a:2:{s:7:\"orderBy\";s:7:\"sorting\";s:5:\"where\";s:11:\"{#colPos}=0\";}}}}s:10:\"tt_content\";s:4:\"CASE\";s:11:\"tt_content.\";a:54:{s:4:\"key.\";a:1:{s:5:\"field\";s:5:\"CType\";}s:7:\"default\";s:4:\"TEXT\";s:8:\"default.\";a:4:{s:5:\"field\";s:5:\"CType\";s:16:\"htmlSpecialChars\";s:1:\"1\";s:4:\"wrap\";s:165:\"<p style=\"background-color: yellow; padding: 0.5em 1em;\"><strong>ERROR:</strong> Content Element with uid \"{field:uid}\" and type \"|\" has no rendering definition!</p>\";s:5:\"wrap.\";a:1:{s:10:\"insertData\";s:1:\"1\";}}s:8:\"stdWrap.\";a:2:{s:9:\"editPanel\";s:1:\"1\";s:10:\"editPanel.\";a:5:{s:5:\"allow\";s:29:\"move, new, edit, hide, delete\";s:5:\"label\";s:2:\"%s\";s:14:\"onlyCurrentPid\";s:1:\"1\";s:13:\"previewBorder\";s:1:\"1\";s:5:\"edit.\";a:1:{s:13:\"displayRecord\";s:1:\"1\";}}}s:7:\"bullets\";s:20:\"< lib.contentElement\";s:8:\"bullets.\";a:3:{s:12:\"templateName\";s:7:\"Bullets\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\SplitProcessor\";s:3:\"10.\";a:4:{s:3:\"if.\";a:2:{s:5:\"value\";s:1:\"2\";s:11:\"isLessThan.\";a:1:{s:5:\"field\";s:12:\"bullets_type\";}}s:9:\"fieldName\";s:8:\"bodytext\";s:18:\"removeEmptyEntries\";s:1:\"1\";s:2:\"as\";s:7:\"bullets\";}i:20;s:62:\"TYPO3\\CMS\\Frontend\\DataProcessing\\CommaSeparatedValueProcessor\";s:3:\"20.\";a:4:{s:9:\"fieldName\";s:8:\"bodytext\";s:3:\"if.\";a:2:{s:5:\"value\";s:1:\"2\";s:7:\"equals.\";a:1:{s:5:\"field\";s:12:\"bullets_type\";}}s:14:\"fieldDelimiter\";s:1:\"|\";s:2:\"as\";s:7:\"bullets\";}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:59:\"tt_content: header [header_layout], bodytext [bullets_type]\";s:10:\"editIcons.\";a:2:{s:13:\"beforeLastTag\";s:1:\"1\";s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:92:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.bullets\";}}}}s:3:\"div\";s:20:\"< lib.contentElement\";s:4:\"div.\";a:1:{s:12:\"templateName\";s:3:\"Div\";}s:6:\"header\";s:20:\"< lib.contentElement\";s:7:\"header.\";a:2:{s:12:\"templateName\";s:6:\"Header\";s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:63:\"tt_content: header [header_layout|header_link], subheader, date\";s:10:\"editIcons.\";a:2:{s:13:\"beforeLastTag\";s:1:\"1\";s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:91:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.header\";}}}}s:4:\"html\";s:20:\"< lib.contentElement\";s:5:\"html.\";a:2:{s:12:\"templateName\";s:4:\"Html\";s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:20:\"tt_content: bodytext\";s:10:\"editIcons.\";a:2:{s:13:\"beforeLastTag\";s:1:\"1\";s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.html\";}}}}s:5:\"image\";s:20:\"< lib.contentElement\";s:6:\"image.\";a:3:{s:12:\"templateName\";s:5:\"Image\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}}i:20;s:50:\"TYPO3\\CMS\\Frontend\\DataProcessing\\GalleryProcessor\";s:3:\"20.\";a:5:{s:15:\"maxGalleryWidth\";s:3:\"600\";s:21:\"maxGalleryWidthInText\";s:3:\"300\";s:13:\"columnSpacing\";s:2:\"10\";s:11:\"borderWidth\";s:1:\"2\";s:13:\"borderPadding\";s:1:\"0\";}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:92:\"tt_content : image [imageorient|imagewidth|imageheight], [imagecols|imageborder], image_zoom\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:90:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.image\";}}}}s:4:\"list\";s:20:\"< lib.contentElement\";s:5:\"list.\";a:3:{s:12:\"templateName\";s:4:\"List\";s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:72:\"tt_content: header [header_layout], list_type, layout, pages [recursive]\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.list\";}}}s:3:\"20.\";a:2:{s:22:\"gameskey_gamesfrontkey\";s:4:\"USER\";s:23:\"gameskey_gamesfrontkey.\";a:3:{s:8:\"userFunc\";s:37:\"TYPO3\\CMS\\Extbase\\Core\\Bootstrap->run\";s:13:\"extensionName\";s:8:\"Gameskey\";s:10:\"pluginName\";s:13:\"Gamesfrontkey\";}}}s:8:\"shortcut\";s:20:\"< lib.contentElement\";s:9:\"shortcut.\";a:3:{s:12:\"templateName\";s:8:\"Shortcut\";s:10:\"variables.\";a:2:{s:9:\"shortcuts\";s:7:\"RECORDS\";s:10:\"shortcuts.\";a:2:{s:7:\"source.\";a:1:{s:5:\"field\";s:7:\"records\";}s:6:\"tables\";s:10:\"tt_content\";}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:43:\"tt_content: header [header_layout], records\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:93:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.shortcut\";}}}}s:5:\"table\";s:20:\"< lib.contentElement\";s:6:\"table.\";a:3:{s:12:\"templateName\";s:5:\"Table\";s:15:\"dataProcessing.\";a:2:{i:10;s:62:\"TYPO3\\CMS\\Frontend\\DataProcessing\\CommaSeparatedValueProcessor\";s:3:\"10.\";a:5:{s:9:\"fieldName\";s:8:\"bodytext\";s:15:\"fieldDelimiter.\";a:1:{s:5:\"char.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:1:{s:5:\"field\";s:15:\"table_delimiter\";}}}s:15:\"fieldEnclosure.\";a:2:{s:5:\"char.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:1:{s:5:\"field\";s:15:\"table_enclosure\";}}s:3:\"if.\";a:3:{s:5:\"value\";s:1:\"0\";s:7:\"equals.\";a:1:{s:5:\"field\";s:15:\"table_enclosure\";}s:6:\"negate\";s:1:\"1\";}}s:15:\"maximumColumns.\";a:1:{s:5:\"field\";s:4:\"cols\";}s:2:\"as\";s:5:\"table\";}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:100:\"tt_content: header [header_layout], bodytext, [table_caption|cols|table_header_position|table_tfoot]\";s:10:\"editIcons.\";a:2:{s:13:\"beforeLastTag\";s:1:\"1\";s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:90:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.table\";}}}}s:4:\"text\";s:20:\"< lib.contentElement\";s:5:\"text.\";a:2:{s:12:\"templateName\";s:4:\"Text\";s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:20:\"tt_content: bodytext\";s:10:\"editIcons.\";a:2:{s:13:\"beforeLastTag\";s:1:\"1\";s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.html\";}}}}s:9:\"textmedia\";s:20:\"< lib.contentElement\";s:10:\"textmedia.\";a:3:{s:12:\"templateName\";s:9:\"Textmedia\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:6:\"assets\";}}i:20;s:50:\"TYPO3\\CMS\\Frontend\\DataProcessing\\GalleryProcessor\";s:3:\"20.\";a:5:{s:15:\"maxGalleryWidth\";s:3:\"600\";s:21:\"maxGalleryWidthInText\";s:3:\"300\";s:13:\"columnSpacing\";s:2:\"10\";s:11:\"borderWidth\";s:1:\"2\";s:13:\"borderPadding\";s:1:\"0\";}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:126:\"tt_content: header [header_layout], bodytext, assets [imageorient|imagewidth|imageheight], [imagecols|imageborder], image_zoom\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:94:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.textmedia\";}}}}s:7:\"textpic\";s:20:\"< lib.contentElement\";s:8:\"textpic.\";a:3:{s:12:\"templateName\";s:7:\"Textpic\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}}i:20;s:50:\"TYPO3\\CMS\\Frontend\\DataProcessing\\GalleryProcessor\";s:3:\"20.\";a:5:{s:15:\"maxGalleryWidth\";s:3:\"600\";s:21:\"maxGalleryWidthInText\";s:3:\"300\";s:13:\"columnSpacing\";s:2:\"10\";s:11:\"borderWidth\";s:1:\"2\";s:13:\"borderPadding\";s:1:\"0\";}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:125:\"tt_content: header [header_layout], bodytext, image [imageorient|imagewidth|imageheight], [imagecols|imageborder], image_zoom\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:92:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.textpic\";}}}}s:7:\"uploads\";s:20:\"< lib.contentElement\";s:8:\"uploads.\";a:3:{s:12:\"templateName\";s:7:\"Uploads\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:3:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}s:12:\"collections.\";a:1:{s:5:\"field\";s:16:\"file_collections\";}s:8:\"sorting.\";a:2:{s:5:\"field\";s:16:\"filelink_sorting\";s:10:\"direction.\";a:1:{s:5:\"field\";s:26:\"filelink_sorting_direction\";}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:127:\"tt_content: header [header_layout], media, file_collections, filelink_sorting, [filelink_size|uploads_description|uploads_type]\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:92:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.uploads\";}}}}s:13:\"menu_abstract\";s:20:\"< lib.contentElement\";s:14:\"menu_abstract.\";a:3:{s:12:\"templateName\";s:12:\"MenuAbstract\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:41:\"tt_content: header [header_layout], pages\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:24:\"menu_categorized_content\";s:20:\"< lib.contentElement\";s:25:\"menu_categorized_content.\";a:3:{s:12:\"templateName\";s:22:\"MenuCategorizedContent\";s:15:\"dataProcessing.\";a:2:{i:10;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"10.\";a:10:{s:5:\"table\";s:10:\"tt_content\";s:12:\"selectFields\";s:15:\"{#tt_content}.*\";s:7:\"groupBy\";s:3:\"uid\";s:10:\"pidInList.\";a:1:{s:4:\"data\";s:12:\"leveluid : 0\";}s:9:\"recursive\";s:2:\"99\";s:5:\"join.\";a:2:{s:4:\"data\";s:25:\"field:selected_categories\";s:4:\"wrap\";s:124:\"{#sys_category_record_mm} ON uid = {#sys_category_record_mm}.{#uid_foreign} AND {#sys_category_record_mm}.{#uid_local} IN(|)\";}s:6:\"where.\";a:2:{s:4:\"data\";s:20:\"field:category_field\";s:4:\"wrap\";s:47:\"{#tablenames}=\'tt_content\' and {#fieldname}=\'|\'\";}s:7:\"orderBy\";s:18:\"tt_content.sorting\";s:2:\"as\";s:7:\"content\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:71:\"tt_content: header [header_layout], selected_categories, category_field\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:22:\"menu_categorized_pages\";s:20:\"< lib.contentElement\";s:23:\"menu_categorized_pages.\";a:3:{s:12:\"templateName\";s:20:\"MenuCategorizedPages\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:10:\"categories\";s:8:\"special.\";a:4:{s:6:\"value.\";a:1:{s:5:\"field\";s:19:\"selected_categories\";}s:9:\"relation.\";a:1:{s:5:\"field\";s:14:\"category_field\";}s:7:\"sorting\";s:5:\"title\";s:5:\"order\";s:3:\"asc\";}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:71:\"tt_content: header [header_layout], selected_categories, category_field\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:10:\"menu_pages\";s:20:\"< lib.contentElement\";s:11:\"menu_pages.\";a:3:{s:12:\"templateName\";s:9:\"MenuPages\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:4:\"list\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:41:\"tt_content: header [header_layout], pages\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:13:\"menu_subpages\";s:20:\"< lib.contentElement\";s:14:\"menu_subpages.\";a:3:{s:12:\"templateName\";s:12:\"MenuSubpages\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:41:\"tt_content: header [header_layout], pages\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:12:\"menu_section\";s:20:\"< lib.contentElement\";s:13:\"menu_section.\";a:3:{s:12:\"templateName\";s:11:\"MenuSection\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:4:{s:17:\"includeNotInMenu.\";a:2:{s:8:\"override\";s:1:\"1\";s:9:\"override.\";a:1:{s:3:\"if.\";a:1:{s:8:\"isFalse.\";a:1:{s:5:\"field\";s:5:\"pages\";}}}}s:7:\"special\";s:4:\"list\";s:8:\"special.\";a:1:{s:6:\"value.\";a:2:{s:5:\"field\";s:5:\"pages\";s:9:\"override.\";a:3:{s:4:\"data\";s:8:\"page:uid\";s:3:\"if.\";a:1:{s:8:\"isFalse.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:9:\"override.\";a:2:{s:4:\"data\";s:21:\"page:content_from_pid\";s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:4:\"data\";s:21:\"page:content_from_pid\";}}}}}}s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"uid\";}s:2:\"as\";s:7:\"content\";s:5:\"where\";s:19:\"{#sectionIndex} = 1\";s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}}}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:41:\"tt_content: header [header_layout], pages\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:18:\"menu_section_pages\";s:20:\"< lib.contentElement\";s:19:\"menu_section_pages.\";a:3:{s:12:\"templateName\";s:16:\"MenuSectionPages\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"uid\";}s:5:\"where\";s:19:\"{#sectionIndex} = 1\";s:7:\"orderBy\";s:7:\"sorting\";s:2:\"as\";s:7:\"content\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}}}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:41:\"tt_content: header [header_layout], pages\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:21:\"menu_recently_updated\";s:20:\"< lib.contentElement\";s:22:\"menu_recently_updated.\";a:3:{s:12:\"templateName\";s:19:\"MenuRecentlyUpdated\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:7:\"updated\";s:8:\"special.\";a:3:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}s:6:\"maxAge\";s:9:\"3600*24*7\";s:20:\"excludeNoSearchPages\";s:1:\"1\";}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:41:\"tt_content: header [header_layout], pages\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:18:\"menu_related_pages\";s:20:\"< lib.contentElement\";s:19:\"menu_related_pages.\";a:3:{s:12:\"templateName\";s:16:\"MenuRelatedPages\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:4:{s:7:\"special\";s:8:\"keywords\";s:8:\"special.\";a:2:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}s:20:\"excludeNoSearchPages\";s:1:\"1\";}s:23:\"alternativeSortingField\";s:5:\"title\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:41:\"tt_content: header [header_layout], pages\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:12:\"menu_sitemap\";s:20:\"< lib.contentElement\";s:13:\"menu_sitemap.\";a:3:{s:12:\"templateName\";s:11:\"MenuSitemap\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:2:{s:6:\"levels\";s:1:\"7\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:41:\"tt_content: header [header_layout], pages\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:18:\"menu_sitemap_pages\";s:20:\"< lib.contentElement\";s:19:\"menu_sitemap_pages.\";a:3:{s:12:\"templateName\";s:16:\"MenuSitemapPages\";s:15:\"dataProcessing.\";a:2:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:4:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:6:\"levels\";s:1:\"7\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}s:8:\"stdWrap.\";a:2:{s:9:\"editIcons\";s:41:\"tt_content: header [header_layout], pages\";s:10:\"editIcons.\";a:1:{s:10:\"iconTitle.\";a:1:{s:4:\"data\";s:89:\"LLL:EXT:fluid_styled_content/Resources/Private/Language/FrontendEditing.xlf:editIcon.menu\";}}}}s:18:\"form_formframework\";s:20:\"< lib.contentElement\";s:19:\"form_formframework.\";a:3:{s:12:\"templateName\";s:7:\"Generic\";i:20;s:4:\"USER\";s:3:\"20.\";a:3:{s:8:\"userFunc\";s:37:\"TYPO3\\CMS\\Extbase\\Core\\Bootstrap->run\";s:13:\"extensionName\";s:4:\"Form\";s:10:\"pluginName\";s:13:\"Formframework\";}}s:13:\"felogin_login\";s:20:\"< lib.contentElement\";s:14:\"felogin_login.\";a:3:{s:12:\"templateName\";s:7:\"Generic\";i:20;s:4:\"USER\";s:3:\"20.\";a:3:{s:8:\"userFunc\";s:37:\"TYPO3\\CMS\\Extbase\\Core\\Bootstrap->run\";s:13:\"extensionName\";s:7:\"Felogin\";s:10:\"pluginName\";s:5:\"Login\";}}}s:7:\"module.\";a:4:{s:8:\"tx_form.\";a:2:{s:9:\"settings.\";a:1:{s:19:\"yamlConfigurations.\";a:1:{i:10;s:42:\"EXT:form/Configuration/Yaml/FormSetup.yaml\";}}s:5:\"view.\";a:3:{s:18:\"templateRootPaths.\";a:1:{i:10;s:45:\"EXT:form/Resources/Private/Backend/Templates/\";}s:17:\"partialRootPaths.\";a:1:{i:10;s:44:\"EXT:form/Resources/Private/Backend/Partials/\";}s:16:\"layoutRootPaths.\";a:1:{i:10;s:43:\"EXT:form/Resources/Private/Backend/Layouts/\";}}}s:9:\"tx_belog.\";a:1:{s:9:\"settings.\";a:2:{s:29:\"selectableNumberOfLogEntries.\";a:6:{i:50;s:2:\"50\";i:100;s:3:\"100\";i:200;s:3:\"200\";i:500;s:3:\"500\";i:1000;s:4:\"1000\";i:1000000;s:3:\"any\";}s:18:\"selectableActions.\";a:7:{i:0;s:3:\"any\";i:1;s:14:\"actionDatabase\";i:2;s:10:\"actionFile\";i:3;s:11:\"actionCache\";i:254;s:14:\"actionSettings\";i:255;s:11:\"actionLogin\";i:-1;s:12:\"actionErrors\";}}}s:20:\"tx_extensionmanager.\";a:1:{s:9:\"features.\";a:1:{s:20:\"skipDefaultArguments\";s:1:\"0\";}}s:18:\"extension_builder.\";a:1:{s:9:\"settings.\";a:2:{s:22:\"codeTemplateRootPaths.\";a:1:{i:0;s:62:\"EXT:extension_builder/Resources/Private/CodeTemplates/Extbase/\";}s:25:\"codeTemplatePartialPaths.\";a:1:{i:0;s:70:\"EXT:extension_builder/Resources/Private/CodeTemplates/Extbase/Partials\";}}}}s:7:\"plugin.\";a:4:{s:17:\"tx_felogin_login.\";a:2:{s:5:\"view.\";a:3:{s:18:\"templateRootPaths.\";a:1:{i:10;s:0:\"\";}s:17:\"partialRootPaths.\";a:1:{i:10;s:0:\"\";}s:16:\"layoutRootPaths.\";a:1:{i:10;s:0:\"\";}}s:9:\"settings.\";a:21:{s:5:\"pages\";s:1:\"0\";s:9:\"recursive\";s:1:\"0\";s:10:\"dateFormat\";s:9:\"Y-m-d H:i\";s:18:\"showForgotPassword\";s:1:\"0\";s:22:\"showForgotPasswordLink\";s:1:\"0\";s:14:\"showPermaLogin\";s:1:\"0\";s:24:\"showLogoutFormAfterLogin\";s:1:\"0\";s:10:\"email_from\";s:0:\"\";s:14:\"email_fromName\";s:0:\"\";s:6:\"email.\";a:4:{s:12:\"templateName\";s:16:\"PasswordRecovery\";s:16:\"layoutRootPaths.\";a:1:{i:20;s:0:\"\";}s:18:\"templateRootPaths.\";a:1:{i:20;s:46:\"EXT:felogin/Resources/Private/Email/Templates/\";}s:17:\"partialRootPaths.\";a:1:{i:20;s:0:\"\";}}s:12:\"redirectMode\";s:0:\"\";s:19:\"redirectFirstMethod\";s:1:\"0\";s:17:\"redirectPageLogin\";s:1:\"0\";s:22:\"redirectPageLoginError\";s:1:\"0\";s:18:\"redirectPageLogout\";s:1:\"0\";s:15:\"redirectDisable\";s:1:\"0\";s:43:\"exposeNonexistentUserInForgotPasswordDialog\";s:1:\"0\";s:23:\"forgotLinkHashValidTime\";s:2:\"12\";s:7:\"domains\";s:0:\"\";s:19:\"passwordValidators.\";a:2:{i:10;s:56:\"TYPO3\\CMS\\Extbase\\Validation\\Validator\\NotEmptyValidator\";s:3:\"20.\";a:2:{s:9:\"className\";s:60:\"TYPO3\\CMS\\Extbase\\Validation\\Validator\\StringLengthValidator\";s:8:\"options.\";a:1:{s:7:\"minimum\";s:1:\"6\";}}}s:20:\"newPasswordMinLength\";s:1:\"6\";}}s:12:\"tx_frontend.\";a:1:{s:18:\"_CSS_DEFAULT_STYLE\";s:3359:\"    .ce-align-left { text-align: left; }\n    .ce-align-center { text-align: center; }\n    .ce-align-right { text-align: right; }\n\n    .ce-table td, .ce-table th { vertical-align: top; }\n\n    .ce-textpic, .ce-image, .ce-nowrap .ce-bodytext, .ce-gallery, .ce-row, .ce-uploads li, .ce-uploads div { overflow: hidden; }\n\n    .ce-left .ce-gallery, .ce-column { float: left; }\n    .ce-center .ce-outer { position: relative; float: right; right: 50%; }\n    .ce-center .ce-inner { position: relative; float: right; right: -50%; }\n    .ce-right .ce-gallery { float: right; }\n\n    .ce-gallery figure { display: table; margin: 0; }\n    .ce-gallery figcaption { display: table-caption; caption-side: bottom; }\n    .ce-gallery img { display: block; }\n    .ce-gallery iframe { border-width: 0; }\n    .ce-border img,\n    .ce-border iframe {\n        border: 2px solid #000000;\n        padding: 0px;\n    }\n\n    .ce-intext.ce-right .ce-gallery, .ce-intext.ce-left .ce-gallery, .ce-above .ce-gallery {\n        margin-bottom: 10px;\n    }\n    .ce-image .ce-gallery { margin-bottom: 0; }\n    .ce-intext.ce-right .ce-gallery { margin-left: 10px; }\n    .ce-intext.ce-left .ce-gallery { margin-right: 10px; }\n    .ce-below .ce-gallery { margin-top: 10px; }\n\n    .ce-column { margin-right: 10px; }\n    .ce-column:last-child { margin-right: 0; }\n\n    .ce-row { margin-bottom: 10px; }\n    .ce-row:last-child { margin-bottom: 0; }\n\n    .ce-above .ce-bodytext { clear: both; }\n\n    .ce-intext.ce-left ol, .ce-intext.ce-left ul { padding-left: 40px; overflow: auto; }\n\n    /* Headline */\n    .ce-headline-left { text-align: left; }\n    .ce-headline-center { text-align: center; }\n    .ce-headline-right { text-align: right; }\n\n    /* Uploads */\n    .ce-uploads { margin: 0; padding: 0; }\n    .ce-uploads li { list-style: none outside none; margin: 1em 0; }\n    .ce-uploads img { float: left; padding-right: 1em; vertical-align: top; }\n    .ce-uploads span { display: block; }\n\n    /* Table */\n    .ce-table { width: 100%; max-width: 100%; }\n    .ce-table th, .ce-table td { padding: 0.5em 0.75em; vertical-align: top; }\n    .ce-table thead th { border-bottom: 2px solid #dadada; }\n    .ce-table th, .ce-table td { border-top: 1px solid #dadada; }\n    .ce-table-striped tbody tr:nth-of-type(odd) { background-color: rgba(0,0,0,.05); }\n    .ce-table-bordered th, .ce-table-bordered td { border: 1px solid #dadada; }\n\n    /* Space */\n    .frame-space-before-extra-small { margin-top: 1em; }\n    .frame-space-before-small { margin-top: 2em; }\n    .frame-space-before-medium { margin-top: 3em; }\n    .frame-space-before-large { margin-top: 4em; }\n    .frame-space-before-extra-large { margin-top: 5em; }\n    .frame-space-after-extra-small { margin-bottom: 1em; }\n    .frame-space-after-small { margin-bottom: 2em; }\n    .frame-space-after-medium { margin-bottom: 3em; }\n    .frame-space-after-large { margin-bottom: 4em; }\n    .frame-space-after-extra-large { margin-bottom: 5em; }\n\n    /* Frame */\n    .frame-ruler-before:before { content: \'\'; display: block; border-top: 1px solid rgba(0,0,0,0.25); margin-bottom: 2em; }\n    .frame-ruler-after:after { content: \'\'; display: block; border-bottom: 1px solid rgba(0,0,0,0.25); margin-top: 2em; }\n    .frame-indent { margin-left: 15%; margin-right: 15%; }\n    .frame-indent-left { margin-left: 33%; }\n    .frame-indent-right { margin-right: 33%; }\";}s:26:\"tx_gameskey_gamesfrontkey.\";a:4:{s:5:\"view.\";a:3:{s:18:\"templateRootPaths.\";a:2:{i:0;s:41:\"EXT:gameskey/Resources/Private/Templates/\";i:1;s:41:\"EXT:gameskey/Resources/Private/Templates/\";}s:17:\"partialRootPaths.\";a:2:{i:0;s:40:\"EXT:gameskey/Resources/Private/Partials/\";i:1;s:40:\"EXT:gameskey/Resources/Private/Partials/\";}s:16:\"layoutRootPaths.\";a:2:{i:0;s:39:\"EXT:gameskey/Resources/Private/Layouts/\";i:1;s:39:\"EXT:gameskey/Resources/Private/Layouts/\";}}s:12:\"persistence.\";a:1:{s:10:\"storagePid\";s:1:\"3\";}s:9:\"features.\";a:1:{s:25:\"ignoreAllEnableFieldsInBe\";s:1:\"0\";}s:4:\"mvc.\";a:0:{}}s:12:\"tx_gameskey.\";a:1:{s:18:\"_CSS_DEFAULT_STYLE\";s:557:\"    textarea.f3-form-error {\n        background-color: #FF9F9F;\n        border: 1px #FF0000 solid;\n    }\n\n    input.f3-form-error {\n        background-color: #FF9F9F;\n        border: 1px #FF0000 solid;\n    }\n\n    .tx-gameskey table {\n        border-collapse: separate;\n        border-spacing: 10px;\n    }\n\n    .tx-gameskey table th {\n        font-weight: bold;\n    }\n\n    .tx-gameskey table td {\n        vertical-align: top;\n    }\n\n    .typo3-messages .message-error {\n        color: red;\n    }\n\n    .typo3-messages .message-ok {\n        color: green;\n    }\";}}s:4:\"lib.\";a:4:{s:14:\"contentElement\";s:13:\"FLUIDTEMPLATE\";s:15:\"contentElement.\";a:5:{s:12:\"templateName\";s:7:\"Default\";s:18:\"templateRootPaths.\";a:2:{i:0;s:53:\"EXT:fluid_styled_content/Resources/Private/Templates/\";i:10;s:0:\"\";}s:17:\"partialRootPaths.\";a:2:{i:0;s:52:\"EXT:fluid_styled_content/Resources/Private/Partials/\";i:10;s:0:\"\";}s:16:\"layoutRootPaths.\";a:2:{i:0;s:51:\"EXT:fluid_styled_content/Resources/Private/Layouts/\";i:10;s:0:\"\";}s:9:\"settings.\";a:2:{s:17:\"defaultHeaderType\";s:1:\"2\";s:6:\"media.\";a:4:{s:11:\"lazyLoading\";s:4:\"lazy\";s:13:\"imageDecoding\";s:0:\"\";s:6:\"popup.\";a:9:{s:7:\"bodyTag\";s:41:\"<body style=\"margin:0; background:#fff;\">\";s:4:\"wrap\";s:37:\"<a href=\"javascript:close();\"> | </a>\";s:5:\"width\";s:4:\"800m\";s:6:\"height\";s:4:\"600m\";s:5:\"crop.\";a:1:{s:4:\"data\";s:17:\"file:current:crop\";}s:8:\"JSwindow\";s:1:\"1\";s:9:\"JSwindow.\";a:2:{s:9:\"newWindow\";s:1:\"0\";s:3:\"if.\";a:1:{s:7:\"isFalse\";s:1:\"0\";}}s:15:\"directImageLink\";s:1:\"0\";s:11:\"linkParams.\";a:1:{s:11:\"ATagParams.\";a:1:{s:8:\"dataWrap\";s:44:\"class=\"lightbox\" rel=\"lightbox[{field:uid}]\"\";}}}s:17:\"additionalConfig.\";a:2:{s:9:\"no-cookie\";s:1:\"1\";s:3:\"api\";s:1:\"0\";}}}}s:10:\"parseFunc.\";a:9:{s:9:\"makelinks\";s:1:\"1\";s:10:\"makelinks.\";a:2:{s:5:\"http.\";a:2:{s:4:\"keep\";s:4:\"path\";s:9:\"extTarget\";s:6:\"_blank\";}s:7:\"mailto.\";a:1:{s:4:\"keep\";s:4:\"path\";}}s:5:\"tags.\";a:2:{s:1:\"a\";s:4:\"TEXT\";s:2:\"a.\";a:2:{s:7:\"current\";s:1:\"1\";s:9:\"typolink.\";a:5:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:15:\"parameters:href\";}s:6:\"title.\";a:1:{s:4:\"data\";s:16:\"parameters:title\";}s:11:\"ATagParams.\";a:1:{s:4:\"data\";s:20:\"parameters:allParams\";}s:7:\"target.\";a:1:{s:8:\"ifEmpty.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}}s:10:\"extTarget.\";a:2:{s:8:\"ifEmpty.\";a:1:{s:8:\"override\";s:6:\"_blank\";}s:9:\"override.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}}}}}s:9:\"allowTags\";s:392:\"a, abbr, acronym, address, article, aside, b, bdo, big, blockquote, br, caption, center, cite, code, col, colgroup, dd, del, dfn, dl, div, dt, em, font, footer, header, h1, h2, h3, h4, h5, h6, hr, i, img, ins, kbd, label, li, link, meta, nav, ol, p, pre, q, s, samp, sdfield, section, small, span, strike, strong, style, sub, sup, table, thead, tbody, tfoot, td, th, tr, title, tt, u, ul, var\";s:8:\"denyTags\";s:1:\"*\";s:5:\"sword\";s:31:\"<span class=\"ce-sword\">|</span>\";s:9:\"constants\";s:1:\"1\";s:18:\"nonTypoTagStdWrap.\";a:2:{s:10:\"HTMLparser\";s:1:\"1\";s:11:\"HTMLparser.\";a:2:{s:18:\"keepNonMatchedTags\";s:1:\"1\";s:16:\"htmlSpecialChars\";s:1:\"2\";}}s:12:\"htmlSanitize\";s:1:\"1\";}s:14:\"parseFunc_RTE.\";a:11:{s:9:\"makelinks\";s:1:\"1\";s:10:\"makelinks.\";a:2:{s:5:\"http.\";a:2:{s:4:\"keep\";s:4:\"path\";s:9:\"extTarget\";s:6:\"_blank\";}s:7:\"mailto.\";a:1:{s:4:\"keep\";s:4:\"path\";}}s:5:\"tags.\";a:2:{s:1:\"a\";s:4:\"TEXT\";s:2:\"a.\";a:2:{s:7:\"current\";s:1:\"1\";s:9:\"typolink.\";a:5:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:15:\"parameters:href\";}s:6:\"title.\";a:1:{s:4:\"data\";s:16:\"parameters:title\";}s:11:\"ATagParams.\";a:1:{s:4:\"data\";s:20:\"parameters:allParams\";}s:7:\"target.\";a:1:{s:8:\"ifEmpty.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}}s:10:\"extTarget.\";a:2:{s:8:\"ifEmpty.\";a:1:{s:8:\"override\";s:6:\"_blank\";}s:9:\"override.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}}}}}s:9:\"allowTags\";s:392:\"a, abbr, acronym, address, article, aside, b, bdo, big, blockquote, br, caption, center, cite, code, col, colgroup, dd, del, dfn, dl, div, dt, em, font, footer, header, h1, h2, h3, h4, h5, h6, hr, i, img, ins, kbd, label, li, link, meta, nav, ol, p, pre, q, s, samp, sdfield, section, small, span, strike, strong, style, sub, sup, table, thead, tbody, tfoot, td, th, tr, title, tt, u, ul, var\";s:8:\"denyTags\";s:1:\"*\";s:5:\"sword\";s:31:\"<span class=\"ce-sword\">|</span>\";s:9:\"constants\";s:1:\"1\";s:18:\"nonTypoTagStdWrap.\";a:3:{s:10:\"HTMLparser\";s:1:\"1\";s:11:\"HTMLparser.\";a:2:{s:18:\"keepNonMatchedTags\";s:1:\"1\";s:16:\"htmlSpecialChars\";s:1:\"2\";}s:12:\"encapsLines.\";a:4:{s:13:\"encapsTagList\";s:29:\"p,pre,h1,h2,h3,h4,h5,h6,hr,dt\";s:9:\"remapTag.\";a:1:{s:3:\"DIV\";s:1:\"P\";}s:13:\"nonWrappedTag\";s:1:\"P\";s:17:\"innerStdWrap_all.\";a:1:{s:7:\"ifBlank\";s:6:\"&nbsp;\";}}}s:12:\"htmlSanitize\";s:1:\"1\";s:14:\"externalBlocks\";s:97:\"article, aside, blockquote, div, dd, dl, footer, header, nav, ol, section, table, ul, pre, figure\";s:15:\"externalBlocks.\";a:15:{s:3:\"ol.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:8:\"stdWrap.\";a:1:{s:9:\"parseFunc\";s:15:\"< lib.parseFunc\";}}s:3:\"ul.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:8:\"stdWrap.\";a:1:{s:9:\"parseFunc\";s:15:\"< lib.parseFunc\";}}s:4:\"pre.\";a:1:{s:8:\"stdWrap.\";a:1:{s:10:\"parseFunc.\";a:9:{s:9:\"makelinks\";s:1:\"1\";s:10:\"makelinks.\";a:2:{s:5:\"http.\";a:2:{s:4:\"keep\";s:4:\"path\";s:9:\"extTarget\";s:6:\"_blank\";}s:7:\"mailto.\";a:1:{s:4:\"keep\";s:4:\"path\";}}s:5:\"tags.\";a:2:{s:1:\"a\";s:4:\"TEXT\";s:2:\"a.\";a:2:{s:7:\"current\";s:1:\"1\";s:9:\"typolink.\";a:5:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:15:\"parameters:href\";}s:6:\"title.\";a:1:{s:4:\"data\";s:16:\"parameters:title\";}s:11:\"ATagParams.\";a:1:{s:4:\"data\";s:20:\"parameters:allParams\";}s:7:\"target.\";a:1:{s:8:\"ifEmpty.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}}s:10:\"extTarget.\";a:2:{s:8:\"ifEmpty.\";a:1:{s:8:\"override\";s:6:\"_blank\";}s:9:\"override.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}}}}}s:9:\"allowTags\";s:392:\"a, abbr, acronym, address, article, aside, b, bdo, big, blockquote, br, caption, center, cite, code, col, colgroup, dd, del, dfn, dl, div, dt, em, font, footer, header, h1, h2, h3, h4, h5, h6, hr, i, img, ins, kbd, label, li, link, meta, nav, ol, p, pre, q, s, samp, sdfield, section, small, span, strike, strong, style, sub, sup, table, thead, tbody, tfoot, td, th, tr, title, tt, u, ul, var\";s:8:\"denyTags\";s:1:\"*\";s:5:\"sword\";s:31:\"<span class=\"ce-sword\">|</span>\";s:9:\"constants\";s:1:\"1\";s:18:\"nonTypoTagStdWrap.\";a:2:{s:10:\"HTMLparser\";s:1:\"1\";s:11:\"HTMLparser.\";a:2:{s:18:\"keepNonMatchedTags\";s:1:\"1\";s:16:\"htmlSpecialChars\";s:1:\"2\";}}s:12:\"htmlSanitize\";s:1:\"1\";}}}s:6:\"table.\";a:4:{s:7:\"stripNL\";s:1:\"1\";s:8:\"stdWrap.\";a:2:{s:10:\"HTMLparser\";s:1:\"1\";s:11:\"HTMLparser.\";a:2:{s:5:\"tags.\";a:1:{s:6:\"table.\";a:1:{s:10:\"fixAttrib.\";a:1:{s:6:\"class.\";a:3:{s:7:\"default\";s:12:\"contenttable\";s:6:\"always\";s:1:\"1\";s:4:\"list\";s:12:\"contenttable\";}}}}s:18:\"keepNonMatchedTags\";s:1:\"1\";}}s:14:\"HTMLtableCells\";s:1:\"1\";s:15:\"HTMLtableCells.\";a:2:{s:8:\"default.\";a:1:{s:8:\"stdWrap.\";a:2:{s:9:\"parseFunc\";s:19:\"< lib.parseFunc_RTE\";s:10:\"parseFunc.\";a:1:{s:18:\"nonTypoTagStdWrap.\";a:1:{s:12:\"encapsLines.\";a:2:{s:13:\"nonWrappedTag\";s:0:\"\";s:17:\"innerStdWrap_all.\";a:1:{s:7:\"ifBlank\";s:0:\"\";}}}}}}s:25:\"addChr10BetweenParagraphs\";s:1:\"1\";}}s:4:\"div.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:8:\"article.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:6:\"aside.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:7:\"figure.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:11:\"blockquote.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:7:\"footer.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:7:\"header.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:4:\"nav.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:8:\"section.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:3:\"dl.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:3:\"dd.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}}}}s:4:\"page\";s:4:\"PAGE\";s:5:\"page.\";a:3:{s:11:\"includeCSS.\";a:1:{s:2:\"bs\";s:71:\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\";}i:100;s:7:\"CONTENT\";s:4:\"100.\";a:2:{s:5:\"table\";s:10:\"tt_content\";s:7:\"select.\";a:2:{s:7:\"orderBy\";s:7:\"sorting\";s:5:\"where\";s:11:\"{#colPos}=0\";}}}s:6:\"types.\";a:1:{i:0;s:4:\"page\";}}}'),(3,'21165d481db3823e23cc30c1267fbb00',2145909600,'a:0:{}'),(4,'8e5a0609f518977551293ade0d99bf7f',1710418622,'a:1:{i:0;a:3:{s:11:\"doNotLinkIt\";s:1:\"1\";s:14:\"wrapItemAndSub\";s:3:\"{|}\";s:8:\"stdWrap.\";a:2:{s:7:\"cObject\";s:3:\"COA\";s:8:\"cObject.\";a:27:{i:1;s:13:\"LOAD_REGISTER\";s:2:\"1.\";a:1:{s:11:\"languageId.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:2:{s:6:\"value.\";a:1:{s:4:\"data\";s:24:\"register:languages_HMENU\";}s:8:\"listNum.\";a:2:{s:8:\"stdWrap.\";a:2:{s:4:\"data\";s:28:\"register:count_HMENU_MENUOBJ\";s:4:\"wrap\";s:3:\"|-1\";}s:9:\"splitChar\";s:1:\",\";}}}}i:10;s:4:\"TEXT\";s:3:\"10.\";a:2:{s:8:\"stdWrap.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:4:\"wrap\";s:14:\"\"languageId\":|\";}i:11;s:4:\"USER\";s:3:\"11.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:6:\"locale\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:11:\",\"locale\":|\";}}i:20;s:4:\"USER\";s:3:\"20.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:5:\"title\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:10:\",\"title\":|\";}}i:21;s:4:\"USER\";s:3:\"21.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:15:\"navigationTitle\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:20:\",\"navigationTitle\":|\";}}i:22;s:4:\"USER\";s:3:\"22.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:16:\"twoLetterIsoCode\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:21:\",\"twoLetterIsoCode\":|\";}}i:23;s:4:\"USER\";s:3:\"23.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:8:\"hreflang\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:13:\",\"hreflang\":|\";}}i:24;s:4:\"USER\";s:3:\"24.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:9:\"direction\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:14:\",\"direction\":|\";}}i:25;s:4:\"USER\";s:3:\"25.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:4:\"flag\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:9:\",\"flag\":|\";}}i:90;s:4:\"TEXT\";s:3:\"90.\";a:2:{s:5:\"value\";s:21:\"###LINKPLACEHOLDER###\";s:4:\"wrap\";s:9:\",\"link\":|\";}i:91;s:4:\"TEXT\";s:3:\"91.\";a:2:{s:5:\"value\";s:1:\"1\";s:4:\"wrap\";s:11:\",\"active\":|\";}i:92;s:4:\"TEXT\";s:3:\"92.\";a:2:{s:5:\"value\";s:1:\"0\";s:4:\"wrap\";s:12:\",\"current\":|\";}i:93;s:4:\"TEXT\";s:3:\"93.\";a:2:{s:5:\"value\";s:1:\"1\";s:4:\"wrap\";s:14:\",\"available\":|\";}i:99;s:16:\"RESTORE_REGISTER\";}}}}');
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
INSERT INTO `cache_hash_tags` VALUES (1,'3697f667c6ada1e0ea4b26eab03b6a29','UserTSconfig'),(2,'0eba7ec1b1917d151fccda947fc067e6','ident_TS_TEMPLATE'),(3,'21165d481db3823e23cc30c1267fbb00','ident_TMPL_CONDITIONS_ALL'),(4,'8e5a0609f518977551293ade0d99bf7f','ident_MENUDATA');
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES (2,'2_3dd9bf81445da22a82c8bc63704fcd24',1710418718,'x�\�<ks\�8��\�\�+4ޝ�ݩ��\�+NvmY��\�,ev�6[*��$\��I?�\��n\0\r�\"5��ٻ��͇XD�F�\�\�\�n�\�{�Oq�V\�\�>��`p�\�2\�7�����\���ټ[k6[>�\�Y�\�ug^�ѩ6\�_ob\�No\�|\Z�{/�~]�x\"J\0\�k\�\�:�\�\�z0���ae��\�\�/�\�O\�䫽0�{��E�W{<\�O\�=�r\�~\�\�h\�V\�L\�<y��&\��.��\�߯���\�2�+|	��ϵx\����\�Sf�nT\�+A�D�ʚ�u\�+��Ā�\�U\�*s\�yE�yT�E*=^h�+�,���\�\�d+� \� \r���\�Sœ�%z\�Y�\�2�cL.Ň\n��Jx<��F>�\�\\�;|ssq\�L\�\��ˤR\�\���\�j�Y\�Md�\�#�\"j%w�A\�d\�Y��xIpy���a�Q4r\��\��]��,\�\r	lE�����\�\�Z4�\\�\�\���\���\�?M.��nk\�jU\�l\�k\r\�m��\�Z�\�j�[�V�\�\�Я�\�h\�\�pr�\�;h0O/F\'\�\�N�\�FW��w�ϦS�]\�<\�}�uľ�jZ\�~5�\�\�\�\�\�\�\�\�\�{rt��\�\�L�O���\��\�\�\�\�+��jϫ\�U��\�\�9����\�\�s���y\�\��a\�sȞD�\�W\�$W6�}�A\�\�G\�>�E�\�9��Lǃ\�\�\�\�ϼn�\�ys�\�\�\�:\�c�N\�ku�\�o��!\�T�\�%}a\�\�!\�\�\�Mѝ�]_O��_/��\��G=O���X�\�Q6�fM\���z���?&��\�&\�cޒO}�����\�DK\�V\��[�\�\�i8	��\�Hq��/\�\�k(�\'���j\�ԅ�#NՄge\�.\�\�B\�\�7�\���\Z{�9�\�\�\�0��s�M���\�\�s᠅\'���X-r\��tp\�\�)?k\�%�S`Ռ\�\\\�\�����ս���,�x��Dr&�=�F\�3�{�w��\�\�\�X�\�\�W|\�\�U\�\�juX\rp\��<����y\�f!?N�\�\�\�F\rB\�\�\�,5�[�]Lװ�0\��@4[���	\�4;��	uf��\�]�>ժ\�X.Rt\�l$\�i�۴��Q\�a8T$�<\�\�Qt)p5-d\�J\�s�\�\�;\�R��ˈ�Dn�A\�\�\�S\�\��Z�!GϪFB)Vk�4~ck\��\��Ű\�\�\�Zl\�\�\�#�\��\�#\�G���\�*&\�\�\��B\�a�o@\�\�\�Y��\0�	�\��\�p�?�0T���DxJ\�S͜\�\�=�S�\�@\�\�Ƈ\�i�Qk��P3БM��s�\"���.A\�\�\�4��\�V�0B\�2\�����S\�$	Vv\�\n�\�tQ\��)ҵ+X����ȟ�q:C\�_\�\�\�\���\Z�V�\�\�\�\'�u\�4��0\�q��aHO\�eF\�;]�M�\�Qnl\�T�����\�\"��+\�\�\�\�q�1\�Ȟj\�L#X\�4\�\�<�\���3w��\�\���\�\�L\���ns\�x��\n�	H{2X\'�ri(��Δkdp�\�X�\�\\����.�Wg\r��Һ\��\'��\�_\�4\�3\�\�t��bZt��\�\�\'r\�a\n�8J\��K\�T7m��\�\���݄A\��Vӥ\�L*o\�o.�\�.k��[��DТ�zlf!��Z+�p�LP\�j�@��7A:50m\�\�5�q\���}-�~��b��eǀ�h�\���u�\�Μ\�\�\�m`�N\\\�\r�1H�4\�}@<lqD��\�9pLJ\�DG��ʤ(;4a�؜@\�6�\�b�\"&3cFQG\�F�\�\�G�B;�]��j��L@vL\'�!��/`�~��\�saFN�q�ka�ô��\��0@Q��%L��+\�\�9��i�縠WC\�W>�T�C8�\�V\�2X���\"`4�\�\�\�8�W\�ʬ.̞jݒnd0k0�Jð@B� e<\r4\� ���:	�+�@e�\�m+\�ڧ2�\�4\����\�\�ܰR�3�X|\�ڧ\�.5-R�B\�\�\�?��\�\�}�\�^,`n ��\�5\�ɹu�n�.$*שL�T\�}�<hHa�ree\�\�q\05#ԹZ�di�u)UK\�\�\�C��\'.����àDq֑�\�y*LY:\�ZBz\�\�f\�2\�\�+\�6h\�\�\�Pz֢\�^\�g\�SuT6˒\�\�\�v�t{�r�x�,\�\�6�R\�m7��b���\�k��F\����r\"\�\�T\�BU�re\"���)�\r4XY3j,\�\�\0�[\�\�\����C���Ԧj/�p�6~�\�ϲ=�=%\�\�.쑂�r$�9�Z�(8\�\�\�Ėԥ��k<FD$<\Z\�ٲ��\�D~6��\�KYb�p~�\�\�\�\�\�\�py\�/\�<ʀۣ\�O»�xͽ��L���\�{P՛xO�Y\�D�e\�L;\�?�0-���m�K\�_����Hp\�\n\�\Z\�����\�%:��ͥ�V:K\�\0J\�\�\�\�1��9\��AH����X&JAqI�8�`~��J���\�7�\�\\\�\r\�\�<@\�\�\r�x�\n,\�d��z�C٢�\�c}Wq\�-�6,���0(\�\�;?[�g)\"1���\�5X&?%\\o�\�2\�@�\�q�\�\�^\�X\�e�F��5\\y?\��\�L*[��\�h۪\Z\�j��r/�\�o\�\�\�\�\�)\�R�&[O��m9\��$�\�=k\��f\�\�#�B�ˍ\�\�7���]jK\��\�@�V�w\�\�F�2vp?HF`�K��U�m\�\r���d��\�P��a��\�C\�\�(\�u�\'&\�^��;�\r0�\�\�G��\�\�Eq򶁔�Yh�k�\�c��O\�o���m\�\�~��\�\�c�׼D\�e�\�Ojq�\�\�&jtu�\�\�r-�C�\�\�pg$p�\nH`\�\�Ǌ�ώ3\�;\n\�tt��ש\�Q�se�~7\�\�h<�$]��hluwD��*��\�\�PebZ��a.&.C3�<~3\�\�h��M4*Zz�fz;_��ht�]\�a\rKW\�7\�j24Lk쾱e�n��\�\�\�\�Ψt���g\�ëwJ�w�\�K&�e\�\�Gi�}@\�\�\�\�)\�\�\�h<1¶��\\\�\�\�&\Z�B�7\�\�\��v�\�\�\�e�aSP{nG4�]��N��7Ǔ\�\��,LӃ!\\-\�\�\���7�\�]0�b\�\�\'x\�\rhu`sqπ�\�\�hrs|5T\��Vk\�C2Rtu�t\0�{u:�])�;��s.\�\��	x���k\�\09\�M5=\���}v��\�i�ԓ�RDS.\�\�)\�S��d�4P���k\�\�	[�\�\�N�Z\�t����x\�7�D\�?1U1ͦ\�\�j\�\�\�!\Z]7!\�k\0᭶\�NC(�;�\�A�\�)�b\�;\�:�4�Wk\�h\n�p\���\�\�h�5���\�\�:	w\��\�uS!����e\���|NH,\��t\�/׼pӁ�\�hꨪqF�\�IG�(/ޢ\�)_�!]\�,��De\0��枥!\�e<���\"��\�!��x껒�e\�\�C?�y;�+g%\�WƆ��\�\�c�l\�\n\�vv�gZ=\�$¶\�L輐�\�d@-!�\�\'�S5\\SU\��GR�*\Z_i�*��k\�\�\'Ɇ�;ԁ\�AA\�x\�\�5[���\��*rBpC\�C�Ί{Z�{�NB\�~b\�\�?��aB��\�i��R=E�ra�\�E>?h\�r\\].L\��ͺ#)1k\�<\��͘¢B=�r�\r\r�!\�Xy\��!\Z@g\�.�^��\'5\�<\'A\�,x\�ٰ�\�-�Ke\�\�\�-9%\"�yL\�!\�*T�@�<�,� ��B�B�\�\�i��\"\�>����I\�9�-P�\�ij3q�,$h\�ٰf\�Q�Tv�\n([o\�<\�B�2˕ۉ\n\�\�\�U�C2w\��\�����\0�uE�\��\�\�j�\�i�Z\�\�u^\�\�b�ߨ�H\�d\�i\�h��\�DV��L\��\�\�t�r�����\Z6S�\�G\0�0kL�\�.\�?�qϿ�\�{\�6=nM��>9��\Z]>s\'\"a�ˣ\�J�]���Y)���f��#uK\�\�\��t\��S]��Sh^[d\�X�5�\�N\�;��\�桓ͳ�\"\�v�8u��1<K�r�\�wQ\���\�\�]So.\�\�p5\�>��_u-@\�h��kD�\'N�7d_`j�\�d\"̽���f_GaB?G&N�\nj)E�X[7\�!�\�\�y�u��.tM�)��>\�ܐ��Ţu�\�1\�\'\\\��s\�\�ޤ�0\��1�۔:|�\�4���\�]8{w50U-\�|U\�T)�\�m\�F\�\�/U�Z�\��J1�\�\\i\n:�5���W\�*\�\�\�+P��\�6�WYJ>�G\��h~$C-_?\0o\��\0ˀTs�g\�\�v\��\�	S\��\�\�+�m�	\�\�_\�\�&@#%q�*�Qc�s/_uY�۬\�\�\�^�\�m3>k�K<oUY��w����\�J0[�������@F)�v��u6�zi���/��i\�Κ�\�\nJ��\�&n\�:\�4hHC\�%��58��\�\� �+��Q\�,��*\ZT\'/���\�Ǚ���8\�[5����\�̱8��8\�,D#\0�hxq�\�\�zD?@׾*��\�\�D��\���)Yv|:x\ZF	��\�ZSJ,\�epǘm\"����%��i���x\"\�(0\�$h�\Z��4\\0�<\n\�\r@\n¬yI\�\���6�\�\�1����:\�&�0�\�=�գ`�_yh\�3C\�)��e\�\n�7\\�\�:��僒\�;jt\�\�tX�m@k�]Ԝ\�WCPxj�<a\�\�:놁hb�\r�?\�\�\��4���{.��I�c��\�\����fs9\�\rGC*����ظ\r�o@p�l�%�\�\�$�ր�9A\�\�(\r�� y�԰\�<�r[P]\�\�\�㾕��$p��\���\�o\�9[\����K\�\"\��ׇ�妸[���\\i݂�\�,\�G8D�>x\�.�d�2g\'\�{C\�K\�\��璁GF�w�\�n>�+�\�\�m*4\"<M+\��\���\�Y뚪�n�sfז\�����\�\�=X��[2C\'�}�ӕ|?\�\\\�\�[�r�.S�\�\�4v\�U>\��\'&�\�\��b*�\Z�\�ѩ�C�$l\�\��MY��`$*<�#���\�?��ÙKWL\�1�3��vj�\0w]\� ]Ã�\�%��J\�$�wYה�#\�\�I83\�\�\��Dh�y�\�\�Y\�5�\���5����X܂�#c~\�\�k\�쓣F\�qѣ\�cN�\���B:\�T�cU\04�L�`a��\�\�:w���=n\�\�\�;R�wt�VD\�4q&o�\�{�?��z�\�\�9\�w�A�\�S\�{ڂ��IK\�A}\\NWĨe\�x�c�\'\�\Z��5\�\�ϜhmiOU�4g�Mf\�\�\�e��>v�]�\����?�Oٱ�\�H�c\�\�\�\�\�\��->w���9���YD�?\�*�\�8YmjWN\��g��,\�\��1@\�l\�\�L�U�\�o$\�7\�@\�!\�:�\�z�fo֘\�g�j�\�޼ΚU�w\Zu\�\�w\�\�z�U�����Ĩ⻒۷�b|\�&^rN�\n�V\0\�K���7\�\�\�\�C��x\\G*\�3�},� ��\�<�~\��\�1T���\rla\r\��\��1zT�4�;�8a�\�\\<?�;\r�-\�\�Aē\�h�:�Q9�_Z��\�!(\�D�\�VA��\�\�������=���֗?&S\�V\n\r\�c�t�\�{��{�\�e|\�AE\Z(�\�)x\���~�\�\�*����\no\�\�&Ǒ*<\n�\�Q\�xG�\�7^Ex\�tE�=\�Zc\�u�ꇼ:j4a\�\�\����\�\�ey��Y\�\�\�\�??�~)\0���\�E8\�]�Ϟ���	�)\�C#s�\Z^�rt��\�����\�\r��\��_\�^;%\�\��\���\�\�J�ÀmYɠ�\���ّ\"\"��#l2��_\�*��\�\�\�!�=�V|R|�CZKp���V�wt\'��c)�\�}\�\�\�\�\�?Ą�f\�\�\�h��\�Gv�\0��\�)@4I��\Zd�\�&~�\�\�o�W~Ko��\�8���PEJ\�%�m�R\�C\�C�nŇ�p\���ځ}E�ml�z\�\�m|c^�h�4V\�ο\Z{h]w\�P\�|zm\�m\�Fu\�\�\���\0vD�\�ֳa�)�u)�~\Z\�+m�7\�\�kE�V�\�C\�\�\�\��\�l\�CUg[�MO\�\��\0Fr\�-�e�E\�\�\�רu�#\r{�\�\���\��>��&��4 &$�;�\��x\rmG�\�W+\�k\�㸈5�r\�6�\�\�\�xw\�\�\�̣\�i4A\�`�\�м\�$L2\�C\�6\�:�\�@\�\�E�S ���yR�P���z�2�\�+�m|+%BIts\�|o\����t\�ÓҲo�\�Q\�ք\�4hm\"\�}�!볤\�IU&�\�EW�p���Q\�J\�};*�0��m!%����\n�\�\Z���oG^�\�4�\�\�F\�D0\�+r�\r\�۳D\Z\�f��\�3�{uC{\�f^?s\0�\�\�?\�裾<N�\�J��\�P\�\�nO\�p\�:\�\�h���\�P<\\\0\�מ\�\�\�ά~C\�*��}<\�\�i\�1���\�\�\�\�:\�隅N�\�y\�O\�>\��Wr�5\�jrD��^�>��{�\�Ĭs\�\��=\�_?w\�oo_T��\�{\0ënG��|2�m\����pr\�\�#�\�ʉ^�\�ip\�\�\�[>N�\�/\�H7�^k[~\�S\�2��rB�\�\�\�Eа�}eC��AUS�=:^>r�V=q<fU>acr?H�\�\�\�\�\�ٸ�\�\�k�V\�\�A��p\�\Z:\�}Mp\�\�b�z�a\�$�����o��Ŋ}#]�Pl\�q\�~2\�81Ρ�\"\�\n��\�fg\�\�P\��|�\�\�t\�v���ҟ�R�\�����\Z\��E�N�\�&ئ\�}\�%ZK5*	�a�lZ\�w\0He����~ 6\�sLN#n����8\�2��SV\�TM2��\�M�!I�\�0gTӌ\�\�\�\�uh\nMA+}m\�C��6Ut��\�:\�\�i�\�\�P�+�+inS5��;�%;�\�V�k\�\�\Z\����]*O1.z\�cn-�����\�bE��m�)ݤI0Pl\�Wa\�e\�ʏw#방�=�ѱ)�Z\��uȞ�n�j�T\��~���Un\�Z6+8n;M٣k9\ng?X/��\�\�u�Њ\�\ZtYo��9\�\�18ܶ.!pQ\����?�\�\�@S\njjlE\�v%Q\�&\�fұV>]��|\�Š?;dq��1Fy\�v\�k\�\��]�g\�W�ٹ�R�C\�I4\�\�2	BhRxNZ���`\0��[wv\�oT�\�73�\0l3�I�\�7\�?���m��	G5(\�\��e�\��H�\�0j\�\�\\c:���֩v��N�\�3.F\��\�V(�A\�Hu\�>��¡��\�8��Ed\�}\�6n�ESGlTJ\�0X\�h\�\�c\�\�\�gJ����@��`�WS��E\�TD\�hY0�Ō\"7�Z݈�zP\�oYc\�Do=.\�AaK��6�֮�{%\�o�5k\�N���䭲F�\�P\�:}EӅY)Ŗ�&\�E�R��_ߤ��QZ\���z��?�#\��\r\'+b+'),(3,'2_402c52cf1e7df196db433aeca6b182ab',1710431092,'x�\�<ks\�ȑ�z�\\&{�l�D�oҲ��,z\�*�\�\�*N�����b��\�\��\�ya@�k\�q\�\�\�\�1=\�\�\�\�\�\�\�\�\0\��\�ST}����\�)���\�֠ژ�\�\r�\�p\�z�\�\�\�f�P�t\�N�A\�س;�FdIg�W}\�\Z�\�ea\�\�t��\�\�\�\�\�\��\�F�U�^�8�?\�篪A«���\�WU\Z�q��x�_�8YӄT\�\�1M^U\�dq\�C\�wGG��1]�q\�\�c?���GʩW�o+0\�m�rT\�\�8\�.+eQ@+	�Ā�~\�EG*Ni�E4�\�,\�.�%��k\�\�\��\�5}d����O�`[q9%��\�GG�W&�\��P!�W	|��1�\�\�؛�w�7wW\�\�\�.��\�_���\�\�\��\Z\�F�\��Ȏ+�\' \'\�Y\�rj\r�\�Ɋ��\�)qy)�a�q�`|M\'\��]\��<�\r	lEŃZ-\�F�y\���\�\�\�\��Br�\����t<�\Z�[΢\�j\�H\�iם~�\�:\�\�v�[� Я�\�\��\�\�\�\�\�1f\�p2�]�\�&ϝǍo�W\�ΟM�z5�9x��\�\�}�մ��jR/G�\��\�\�\�\�\�&�\�ɜy[�T�\��\�\�\�7\�{Uu�j\�\rH��.\�|T\��G]�4H\��=\n�X?d\�\�\�\'��\�\�\�\r��_=\�\�\�/r\�\�\�\�\�t6ޏ\�\�M\�\�\�[n�\�t�\��\�p\�}\�\�7i\�kx\�&\�G5տ|I_yR�\�z�+���\�\�\�\��\�%��A����\�\�牳�ck4=\�&9\�DMA8��?�&\�)}D0�.qWt摄T_�A-eG\\�Kl���/\r\�\�Oz\�\�)h_�7֐S�qO49\�ԃ�#NՂga\��\'\�\�w\Z\��{1\�nw�\�\�\�0pP�)˦\�\�۷\�N(�\�\�WD,9�`:�z�\�Ô�%뒧�jNb*\�n\�\�@\�z\�fk\�E%+\�q��\\00��\'�Fh}ƋS�I��\�{\Z�`C=�\�A�.\�4`5�I\�4ti�\�`�!�\�4M�7w�5(AS��8����F��0\��@4[���	ش\0;��	�f��\��KUvʗ)�q6���mZ���\� 	�.|\Zx\�8<�\���6�q\�6T!|;��0\�<$�&\�?��d\�Ɣ��?�\�Y9Z(\�:J\�1�\�_JN�y+�\�t\�\��v\�NU��P�ϙ�(i<ԲdW01�\�\�x\0\�|J>֜5\�@��3�\\�j\�q9\�C\�	C�K�K��T>9\�67�\�X\�Y#c�\�ѭqB����D\�,�dk�B���\�\�^S\�\'V\ni\�4FhX��кp��<I������\�\�-=�ْ�4�\�\�H��)��s\�al!\�؃\�H\�ܩ�\�J78�$�l������Q\�\��\�\�|��k8�\�\�\�9ʍi����7\�[�\�l\�<�<s\�>\0\�3ɝY��tCü\�8cq��\�.7�\�.g�\��u�\��\�۬T8�L@\�\�\�~�dʥ)\0�:S���\�g`I\ZS~�����vm�5�&J\�3\�B�p�\�iXU\��ZuC�\�)1y�[\�DA\n\�p�\�\�\�?�n\���\�C��n\�M\�ކ\�^],�3\\\�\�O\�o��E�..\�L0/j�F\0\�N����R�vo��\���]$ƄƉ\�WX\�-�������\n\���\�኱uN�t��:=p%W\�O\�0\�\\\�\�\�1�š�h%�Ձ#���>\n\�&Eء)Y\�\�¶i�\�-v*bR3f\�q86�0��\'>\\\�a\�\�\\\�d\n��:!�\�}\�H\�[QG=a\�d\'{V:L\�P\�g�\n\�\0�\�{\�X\�D]I�\�:\\(L��X\��\Z-`�~�\�i��\�`$��V$�+/F\�(\�^�x��\�\�\�\�\�t+ �Y�\�M\Z�\ZR\�S_b-\�P��3���\�QT6*طy*�I��\�X�Җ��y��;R*xj�O=\�Tܥ��E\�T�x\�\�\�\�ҹϓ\�π\�M\�Vq��:9\�\�\�ӅD\�:�Ƀ�JڔɃ�\�W�\�\�P3L���$+c,t�R�t9��=x�x\�2x\�q�%���\\�\�0e\�\�\��$p\�\�\�\�e2�\�W-۠ŗ\�\�G@\�Y���\�\�\�jP\�,+�\n\�і\�eʕ\�}�8GGAJE�\�����2�>E$\�P��3*�\�1ډ��\�S\���\�\�\�&EI�iЃ�5Ӎe\Z����=k���쐁)-.�%\�Ke���m��l�\�\�Dz܅=�R��s\�V\�\�\Z�ذCw)c�\�Y�\�H	�\n��\�\�?�T���m�[\�R��)��m�����\�w<�.\�J8�2`\�(\��\�.?��\�`���4\�b��F\�)8���dC���	\�\�\�\�\�׻\�}\�X:\�\'�p���H\ZL]�#�\�\\*h��t�t`-$�1�P\�\�x\���{%�\�g�2Q\�Ðrm:�Ï\�H�iX�\�1\�\�\�P\�\�\�\�t�\�T�\�p�(�,N\��o\�:�-\Z)=�w�\�\"i3����z\n��\�Z�\��-�\� dSpz\�X\�\��2�y,\�zG5�Iz��{d?\��\�2/6\"�\�p\��t+3�$*\�ՠ}�j���Y\�\�1�$Ro�\�Dw?ߧlKY�\�=�\��드g\��\��K�4\n\�!7�\�8L\�vm�-Y�OC�^�\�%[;=\�\�A=?�5.�\�\�-辡w$�{̒�rC\���\�{�ݣt?\�\���D�}�\�\�w�\�r\��:O�\�\�;\nR�f\�;X\\�\��G|\�xg\�gi\�\�\�\\;3ļ\�5\�.�����6�\��w0F�kQ\Z�NF#�sU@�7�=�|v�\�W]�\�g\���n㫰�C�\�([\��\�\��\�E\�\�, \�I$�\�v\�@D{��_�D&�\��\rs1q�\�\�\�\��h\�k�`\��\�\�\�7��\�\�\�\��P�\��shX�R��7ӑbZ\�\��-Cu?\Z\�ޟOF%3E�<��ݼ\"|��]��\�|�\�4L�\�r�nOρoƓ��Cd\�\�.1\�X:t�aG��\��\�\�!\r��\�s?r��\�\�\��|:���:��\�A\�{�\�jY�&?�d	\���?�\�o@���{t�\�\�ӻӛ��_�\�\�i#U@\�P�@&��7\��\� �+���*]���������\�\�U�\�c�\�3\�g+�KݖJ=Y)E4\�=�S9�H�JeY���^I��u$\�v��\�\��\�]	q��2P9��b�b�M�\Z�\�\���\�%E4�n�\'\�\�\0\�\�\�����&̓.\�6�a\�;\�:�4�W�^8�K�\�\�\�z8�\Z\�\�\�\�f���y�\�u3\������\�z�b��\��\�_�yi���ڣ%��\��r\'\�\�y\�n��\��;\�\�C\�\�\�&\"p�4\�<\r`/\�\�\�	B�X}�z�g�-YY\�M�\�a\�\�\�1Mb�rm�D�\�\�\�\�{{̖-Z�\�\�n\�U�˂X��\�:g2/d\�QPCH>��\�D\r\�L}U���\�W=O]��q\�L֓d\�4���Y��,�M\�\�k�eA�\�ET\�\��ڇ&�\�\�1{�N�\�9�\�\�\�\�\���	Y\�/\�g�\�)\Z��K�8�-\��A��\�r��OL\�I��)�\�\�\07c�\n\��\�mJ�\�«\��\0}\�\�\�\Z%`8y\\\"\�s�͒&V�	k\Z\�¸�\���\�nEu\"R7G�l\�\'�BUk\0\�\�˂?\�?\��\�h\�=\�\�HE�}.�\����J[\\�|\��vf2q�,$h\�\�4�\�R�T��\�u�\�\�i\�,Ny�+7ԉ��D�da%\�\�\�KP\�g52\�RA��\r6\�\0O3ѧ(�qe�\r\�o\�LZ\�df�i\�hx\�\�D\��T\�	�\�\��fe;:kF5M�\�\'�(�\0\na֘\�ك\�}\�\��溭zܫz3yr2:��|\�:NYB�G9\��\�\ZIZ�Rh#\�\�@\�V\�}�\�ٜx\�6C�\nм��]#1\��+8m\�x`󫗇Nw\�\Z��\�\�\�\�b\�\�`\�,�ʽѾ��W;�ݎ\�xuY����\��jH\�\0Z\�륾F\�z\�$xC\��\�(O�Lݫ��5�\�\�\nL\�\�H�\�*_A-%(a�q\�,\"Z6�\�Rǰ\�J֔�\"��\�̍\�7�X���=��k�`�z\�\��\�\�]:|����)l3\���V�)՗d\�\�Ż���j\�\�ZfB\��M�dh\�\�(�G��T�jt�\�	\�@�K�)\�Itt\�G\�9OP�W8\r^�zY���je\�\�\�UUW\��\����q\�\�\�ˀDs�g\�\�v\��\�\��\���x\��<ܗ�\�]�M�F�\�Q\�\�1\��wDW\��īW톷 �~\�s��C:�\�\0��~�\�v��N�\����\�\��t�2\�:&\r\� �Z\Z��:�>�\�4�%�⿬��-\�?RŖ 0��aR�\�\�u����*�=1�p\�)y�A^\��¦�fa\'\�\�ei\�D\�\�>\�\\\r	ęފ�\�L�d��Q\��\�\'\�\�E���+��\�\�\"\��D��#O��#\�\�\�\�f\����Q�\�H�r�,U\� O\� DFA��O9���j�k�\�š�OЬ\�E\�\�`Ixpu�oRd\�+}s�0�C+��]\�t�X\� ���iuu\���40\���\�ٲL1\�\�\�fZ�\�JCN\�nd�ꌯ\��P\�\�\"@�u٨�u�@SZ<���\�\�?\�Ƭ5\�R\�t^���\�-\���	g46H\�^\\`�\�J-b�g\�S}��\��$$\�l\\�\�7 8n6�J�\�\�9}ԭ����\�\�F�P9\�\�P��m�i�\�r_�p�]\n;\�\�\��A����\�->g�~\�\�oྴ\��?\�A\�]sS<�\�\n~\\��n�F��#\"�F�<wW~�J����FzE�Mּ\�\�&\�\�\��\�\Z.I�-\�\�\�L\�4\�\"x�&F�C-�7�?Rk��.��c֙�\�wpYH�)5�~0vg\�\�b�q\�\�GNW\��0\�\�s\�\�\�^:O\�\�\�\�\�W��y��n	��u%\�$`�OU�%a+�f�Mvc�#Q�\��Tl���\�4�\�t\�:\�<�|n5띚<µ\�0H��`\�}E\�F%\Z\�4\�Y\�TR�{\�ķf\���\�?�4	\�,j\�}\\ig\�h�)\'ޟ�	M\�\�\�\\#\�kEʓ\�\'K�\�\�EW��s�\rM\�c�|�\n�Ɵ\�!X�n\Z\�\�#\�.\�c�[�;�A+\�}�֚ȵ\�ę�\�\0�\��C3_d\���?4%\�y��\�ޤ�NW}\\͆7�Q��\�\�\�\\O\�5lk�\��\�\�Ҟ�|.hN_�̆*\�U˲�;y\�>\�lσQIF\��kL��8\��\�-Ųӻ\�|\�(uc�|Ƴ\�4�E\�\�r�:�]8;о^�\�8��\�\�\0��g3IVue�@3��&cb5\�U[\���V\�\\,\�\�z�\���AZu�v�\rJ�\�\�r�u��[���?�Q��95/�\���N��T\�4\�XZhe�\�\�eo\�\�ڂ�\�6���\�\'��s\�:B�u;O�\�=��qEXanb`X.8T�{�\�_��\�Ɏ(NS7\�\����\r?iR�um�+\��\�>n7k��28^�\�^�S��\Z�;�{��lN�/(TĦ\�=�O\�\�\�\�\�tA6XX�;\��>�J谁��\�\�\�o\�Gu��\��\�:��[��\�9su\��\�\�\��\�|\�U�&D\�\�-5�\\�*�ȫ�f\���u��\���z_�\�Z\r\�Σ�\�\�ٗbGG�m��\���\�\��L\�U%\Z�\�\������!ڻF̆\�z\0��\�E�R}m�Tշ���_��=ؖU\�/Sh3;R��\��TL\�j�\�Z\Z<�g\���N�\�ab\�k���\�\�\�\n�\�X\��\��C\\��\�X�w�y+\��s��\�-�Z� �$Lt\r�(q�\�\�\�T~Kx�\r�$5Q�*T\�\�\�\�U����5݊k\�p\���ڱy���l�x#\�m|�ޙh�%V\�ο\Z�J]W�($�~\�\�m\�F\�\�\�ͻ��XwD�\�׳�����)�f^\Z\�i�w\"ؑ }/Z\�Kcx��\�+2������Ӯ\'nwW\0��\�ɲȢ\�g\�ײ߉��~Q�\�仿\��\r��\�\�j?�\�������J\�ݱ\�{ѣf�\�.v�!=ޝ\�xX\�\�Ar\Z\�_=X\�$P��X��\���i�\�@g�輖�\�_\�p3h C�:��Q�\0�x�2�\�۬|�%BHtk\�|o\����҇\'�m^lͣ,ƭ5J|)���0\����ϐ.\'Iw-/�H�zK��g/#\�\���\ZbpޖX����ܦ\�-4%�0P0};r\�\��\�\'����\�>b�rؐp\�[��mxޞ%\�p6㄄�\n܋\�\�6\�\��`u���QF\�\�i\"=V�UU�u�c\�TG�s��b͖\��4\�\�5�\�\�Np\�\�\��X\�\�\�7t�\�9\�g�O���\�\�\�\�@�>\�ꩮY\�D\Z����\�\��p�Lװ�\\M�ht!\�+?Bs�Q\�CIL�C�\�\�3O�\�sG�\�\�Ed���^q;:�\�k3\�\�BY1+-.^P�+��\�8�\�.��d5r���\�\�N\�\�\�H�\�)#\�+\�Hd\n���&�w$l\�1�\�+�Gǫ\�O._��C\��\�\�,*-\�\�c�\�\��$\�n����q_���*\'�͙]\��v�\��\�{G*�l|��,\�\�\��bW�\�u\�\�X�V\�W@�\�mv&m\r%\�\�W\�]7\�A�*�\�+�:�o���b?[\�\�6\�\�d�Ͼ�Ck��B%0��\�\n�\0)v��\�\�\�n#~�\�j\�\�S�ױ��\�t#@dj\���\�@\�Qo�+3Zu\r�5��F\�a�#s�BU��?\�\�š�NTG\���:\�\�Y�\�\�\0\�|�N\�Z\�օ�\�\�(�l��/X��q o�j\�o\��\�ty�r\�.�\�\�l��\�\�+\n�lU���\�F�~�~���x7��Z���q��)U�FdK[US�2�|\�+���s�:٬\�4e__\�Q8~�bv�\�ܽB+�k8\�e�bIKW\�\�z\Z�݈� \�/[�\��m~{\0M)�%�a����O\�ͤcY}�^�=Ġ?;dq��1Jyv\�\�k\�\�\�g\�\�\�ٺ�\�@���>��\"0�P�\�(�6�/\��\0h\�w\�\�|Ь��o�*>�fV�x;h�]\��\�bo�jZ:���B]�ͮ\�\�?^�\�0j\�\�Rb:��\�\�\�{-�\�i\��K�Ѽ��\�\n\�P:]��fb-q�\�$8�c�t����l��\�q�\�\��iT�	ϝ`\�\�\�g�2���|OB	P\���E\�D�\�HYP�Ō\";�Z߉�z\�\�\r޲&��\�7zR\�C�-E\�Z�Z�\�\��D�L\�j:\�~\�e\�h\�V�# \�u��MLf�{����\�\�wR�H\�~�SN�uM��\'g{��\�\�Cr%');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES (2,'2_3dd9bf81445da22a82c8bc63704fcd24','pageId_2'),(3,'2_402c52cf1e7df196db433aeca6b182ab','pageId_2');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pagesection`
--

DROP TABLE IF EXISTS `cache_pagesection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection`
--

LOCK TABLES `cache_pagesection` WRITE;
/*!40000 ALTER TABLE `cache_pagesection` DISABLE KEYS */;
INSERT INTO `cache_pagesection` VALUES (1,'2_0_222419149',1712924222,'x�\�\�n�0\�_�\��$$\�j\�:i��&�v�pS�#l�eU\�}\�|\�\�V�n\r�\�M�\�\��s���� z\�\���9\�8򢇃�\�Sr.�М(#�h\�\�z4uΕ����;\��#�-)c~\�\�θ�\�\�BbI:\��T2�\�$r.yV_B\�o\���t\Zk�Y\�0�\�\�\"�Ꭶ)\�;Ă)K)i\�OF\�S\�\ZܒxS\�Pa�֫!�!�yŗպ�\"� )����tr@�\�2\��-\�8\�Wj8�H\�Xb�\'�J\���V*bA%Q\�k�f�\�e�i\�#\�s\�ۃ\Z�\�\r\�㌧�\� j��{��u\�\�\"fdKX/\�A\��{�}#\�襳ןp�T�_\�썜\�C�V\�w\�*S�̺�\�V͛��_1\�\�V��/��\�\�\Z�曦�1\�=4�x\�\�J��-=|ˠt�\�3��\"��t\�\�\�T%��\�\�1�\�):ҋ﫨7�\�A��|P?\Z\�=�b	n\�~G��\�\�\�QZ�@�\n@����{��+�\r�u�6\�D�.�+z�E_���35��z\"Pg�\�}\�?\������\�ڦ\�\�>\���>g]Q�jqB\�Y�=l͏;t&8�[\\��\�ν�s�j\�h\�B�\��{�\�[R\�\�\�I�\\\�Z�K\�F��\�u��\�|⇳\�B;0f^dvAdUXg\�=}j_-\�~VE_V�R=W~�d\�c\�\r0oXJ�\�.�X剝	�b\rKԳ�L�\�wcd@���\�\�\�d\�\�N59yq=��$�\�65��ӃAT;\�\�\�\�O�\�9�\�\��-\�*,skrr�\�/eR\r@[��\�^3{&�7v&W��e.\��t��t`g}\�Wl�oG(�\�`�\�\�=Z�\�\'\'�J\�\�\�Z\�\'\�\�\\�\�8x\�\�(�\�%�I\�\��\�\�\�ll\�o\�k\�\�n_�9�m�\Z�؝�\�x�6�|\��	�$\�\�J�\�:��F7,���u�qj\�$p\�\�7E\n͒\�)\�kyM��(d\�*�H%ɰ��\ZL^���\Z�\�|\�\'_��;\��\0��(�');
/*!40000 ALTER TABLE `cache_pagesection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pagesection_tags`
--

DROP TABLE IF EXISTS `cache_pagesection_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection_tags`
--

LOCK TABLES `cache_pagesection_tags` WRITE;
/*!40000 ALTER TABLE `cache_pagesection_tags` DISABLE KEYS */;
INSERT INTO `cache_pagesection_tags` VALUES (1,'2_0_222419149','pageId_2'),(2,'2_0_222419149','mpvarHash_222419149');
/*!40000 ALTER TABLE `cache_pagesection_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES (1,'1__0_0_0',1712924222,'x�M�Mr\� �\�\�	�Ӧ�|���I\�1�\�#�n3�ܽ�]��@�\'\�(\�\�hT<\"ԠgU3��JkUJ\��\�	GM���\�\�w\�h�\�ȆqïB{�#����~��o0�ޟ\�R�\��3:�\�\�N�7G_\�Z/i92�~o�\n�\�\�;�+\�n�4̶2m��b�?,\�3�\�e0\�\�\�ҍ\�nq�\��\�R��N5\���h8�D�\��d\��ǿ@\\\�\�1�D�%\�S\n��\�\�*���\�\�ehO��\'�/SIP\�\�dl����l�=N\�\�\�\�_X[�/'),(2,'2__0_0_0',1712924222,'x�\�Mn\� �\�\�	�\�_|�v�M�G\�L\\\�Xf\�6�r\�v@����\�\n\�cx\�iY\�O+\�FˊwA\�Rֈ&���֪\�\�Y\n�g��`V	��\r-\r�	�gj\�q�\�_tA�\�^\�*��步c\�=H\�\�\'J�ެ1\�`-~s$�}~\�Q\n\�fK��8�\�F��(\�\�\�\�r\�A\�|��tt\�\"\�t �\�\"�}��d;\�\�\�ue}\�&\�\�n�ؠ�%i3m��\'5l̫6P�˼^�v\�Y�z4�3u\�\�\�V�;\�\�/��\\6\�\Z�\�\\|���\�\�x\��o\�\��|��4\�'),(3,'1__0_0_1',1712924388,'x�M�Mr\� �\�\�	�Ӧ�|���I\�1�\�#�n3�ܽ�]��@�\'\�(\�\�hT<\"ԠgU3��JkUJ\��\�	GM���\�\�w\�h�\�ȆqïB{�#����~��o0�ޟ\�R�\��3:�\�\�N�7G_\�Z/i92�~o�\n�\�\�;�+\�n�4̶2m��b�?,\�3�\�e0\�\�\�ҍ\�nq�\��\�R��N5\���h8�D�\��d\��ǿ@\\\�\�1�D�%\�S\n��\�\�*���\�\�ehO��\'�/SIP\�\�dl����l�=N\�\�\�\�_X[�/');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES (1,'1__0_0_0','pageId_1'),(2,'2__0_0_0','pageId_2'),(3,'2__0_0_0','pageId_1'),(4,'1__0_0_1','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usergroup` text DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(2048) DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` text DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` text DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `canonical_link` varchar(2048) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1710177431,1710177431,1,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,0,NULL,0,0,0,0,1,1,31,31,1,'Home','/',1,NULL,1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1710177431,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'','',0.5,''),(2,1,1710178228,1710178221,1,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Games','/games',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1710178457,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,''),(3,1,1710178230,1710178225,1,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'addgames','/addgames',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1710178230,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(255) NOT NULL DEFAULT '',
  `fieldname` varchar(255) NOT NULL DEFAULT '',
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1710236932,1710236932,0,1,'2',0,'/image/Grand_Theft_Auto_V.png','66afa09b80926556f07749c4f2f2f93156761a4e','b8d68d9750e37d43b20bdcf6675828cdb80e7b77','png','image/png','Grand_Theft_Auto_V.png','f05e151e3859ae304e4514dcc8bade866a46c1f8',110757,1710236925,1710236925),(2,0,1710236932,1710236932,0,1,'2',0,'/image/Helldivers-2.jpg','e37bbc8a5fb440ebfac7755cde024b2116f2fbe1','b8d68d9750e37d43b20bdcf6675828cdb80e7b77','jpg','image/jpeg','Helldivers-2.jpg','47898cb84c45c80b9361dbb1e240016965188bad',207833,1710236925,1710236925),(3,0,1710236932,1710236932,0,1,'2',0,'/image/NFS_Carbon.jpg','17c9abb4452c169fe4d68a5f7ed35a97b6f1d8a5','b8d68d9750e37d43b20bdcf6675828cdb80e7b77','jpg','image/jpeg','NFS_Carbon.jpg','2c3b90935205818c911df97768a97b8bb641af47',99854,1710236925,1710236925),(4,0,1710331002,1710331002,0,1,'2',0,'/image/965616-l0.jpg','dda42c44bb870a903248b2d73d8bd725c3ef3cc4','b8d68d9750e37d43b20bdcf6675828cdb80e7b77','jpg','image/jpeg','965616-l0.jpg','a8027df3a33051c212e60519837ae6f82c175a4c',129428,1710330986,1710330971),(5,0,1710331021,1710331021,0,1,'2',0,'/image/Minecraft.jpg','6ca2698c7d1a500fae25b1d729f9b9215863eba8','b8d68d9750e37d43b20bdcf6675828cdb80e7b77','jpg','image/jpeg','Minecraft.jpg','a8027df3a33051c212e60519837ae6f82c175a4c',129428,1710331017,1710330971);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1710236932,1710236932,1,0,0,NULL,0,'',0,0,0,0,1,NULL,220,272,NULL,NULL,0),(2,0,1710236932,1710236932,1,0,0,NULL,0,'',0,0,0,0,2,NULL,600,900,NULL,NULL,0),(3,0,1710236932,1710236932,1,0,0,NULL,0,'',0,0,0,0,3,NULL,706,1000,NULL,NULL,0),(4,0,1710331002,1710331002,1,0,0,NULL,0,'',0,0,0,0,4,NULL,787,1024,NULL,NULL,0),(5,0,1710331021,1710331021,1,0,0,NULL,0,'',0,0,0,0,5,NULL,787,1024,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (1,1710236932,1710236932,1,1,'/_processed_/1/1/preview_Grand_Theft_Auto_V_e8c5020c29.png','preview_Grand_Theft_Auto_V_e8c5020c29.png','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','f05e151e3859ae304e4514dcc8bade866a46c1f8','Image.Preview','e8c5020c29',52,64),(2,1710236932,1710236932,1,2,'/_processed_/b/0/preview_Helldivers-2_ff6a146296.jpg','preview_Helldivers-2_ff6a146296.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','47898cb84c45c80b9361dbb1e240016965188bad','Image.Preview','ff6a146296',43,64),(3,1710236932,1710236932,1,3,'/_processed_/0/5/preview_NFS_Carbon_62afeadb64.jpg','preview_NFS_Carbon_62afeadb64.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','2c3b90935205818c911df97768a97b8bb641af47','Image.Preview','62afeadb64',45,64),(4,1710236941,1710236941,1,1,'/_processed_/1/1/csm_Grand_Theft_Auto_V_d53f0f9ba3.png','csm_Grand_Theft_Auto_V_d53f0f9ba3.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','f05e151e3859ae304e4514dcc8bade866a46c1f8','Image.CropScaleMask','d53f0f9ba3',122,150),(5,1710236941,1710236941,1,1,'/_processed_/1/1/csm_Grand_Theft_Auto_V_a7a23368b9.png','csm_Grand_Theft_Auto_V_a7a23368b9.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','f05e151e3859ae304e4514dcc8bade866a46c1f8','Image.CropScaleMask','a7a23368b9',36,45),(6,1710236951,1710236951,1,1,'/_processed_/1/1/csm_Grand_Theft_Auto_V_67d033b446.png','csm_Grand_Theft_Auto_V_67d033b446.png',NULL,'a:7:{s:5:\"width\";i:200;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ba6f3999daa64879a5c9fcc4ffddd553a4e200d5','f05e151e3859ae304e4514dcc8bade866a46c1f8','Image.CropScaleMask','67d033b446',200,248),(7,1710255106,1710255106,1,2,'/_processed_/b/0/csm_Helldivers-2_8c319d6cdb.jpg','csm_Helldivers-2_8c319d6cdb.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','47898cb84c45c80b9361dbb1e240016965188bad','Image.CropScaleMask','8c319d6cdb',100,150),(8,1710255106,1710255106,1,2,'/_processed_/b/0/csm_Helldivers-2_c5576562ac.jpg','csm_Helldivers-2_c5576562ac.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','47898cb84c45c80b9361dbb1e240016965188bad','Image.CropScaleMask','c5576562ac',30,45),(9,1710331002,1710331002,1,4,'/_processed_/e/8/preview_965616-l0_d9f5448296.jpg','preview_965616-l0_d9f5448296.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a8027df3a33051c212e60519837ae6f82c175a4c','Image.Preview','d9f5448296',49,64),(10,1710331021,1710331021,1,5,'/_processed_/4/8/preview_Minecraft_c973b3f480.jpg','preview_Minecraft_c973b3f480.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a8027df3a33051c212e60519837ae6f82c175a4c','Image.Preview','c973b3f480',49,64),(11,1710331023,1710331023,1,5,'/_processed_/4/8/csm_Minecraft_bb2f5dd4af.jpg','csm_Minecraft_bb2f5dd4af.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','a8027df3a33051c212e60519837ae6f82c175a4c','Image.CropScaleMask','bb2f5dd4af',116,150),(12,1710331023,1710331023,1,5,'/_processed_/4/8/csm_Minecraft_bb75c03c88.jpg','csm_Minecraft_bb75c03c88.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','a8027df3a33051c212e60519837ae6f82c175a4c','Image.CropScaleMask','bb75c03c88',35,45),(13,1710331159,1710331159,1,3,'/_processed_/0/5/csm_NFS_Carbon_527563fbe1.jpg','csm_NFS_Carbon_527563fbe1.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','2c3b90935205818c911df97768a97b8bb641af47','Image.CropScaleMask','527563fbe1',106,150),(14,1710331159,1710331159,1,3,'/_processed_/0/5/csm_NFS_Carbon_09d1ca56ca.jpg','csm_NFS_Carbon_09d1ca56ca.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','2c3b90935205818c911df97768a97b8bb641af47','Image.CropScaleMask','09d1ca56ca',32,45);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) NOT NULL DEFAULT '',
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES (1,3,1710254497,1710236947,1,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,4,'tx_gameskey_domain_model_games','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(2,3,1710323731,1710254482,1,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,5,'tx_gameskey_domain_model_games','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(3,3,1710323722,1710255371,1,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,6,'tx_gameskey_domain_model_games','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(4,3,1710331079,1710331079,1,0,0,0,0,NULL,'',0,0,0,0,5,7,'tx_gameskey_domain_model_games','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(5,3,1710331525,1710331181,1,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,8,'tx_gameskey_domain_model_games','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1710178414,1710178414,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1710178221,1,'BE',1,0,2,'pages','{\"uid\":2,\"pid\":1,\"tstamp\":1710178221,\"crdate\":1710178221,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Games\",\"slug\":\"\\/games\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$5523b56f6b6bd5afefb92133f4d0296a:f11830df10b4b0bca2db34810c2241b3'),(2,1710178225,1,'BE',1,0,3,'pages','{\"uid\":3,\"pid\":1,\"tstamp\":1710178225,\"crdate\":1710178225,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":128,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"addgames\",\"slug\":\"\\/addgames\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$fc344f5ce5da8edd1a6ad624db58b1c7:fe15eeb7d49e64e2cea91ab53fcf0db1'),(3,1710178228,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$d5ded38aa32a4bb4af5f872207827148:f11830df10b4b0bca2db34810c2241b3'),(4,1710178230,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$7f548e8b10ae6231f00625609a75d866:fe15eeb7d49e64e2cea91ab53fcf0db1'),(5,1710178428,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\npage.10 = TEXT\\npage.10.value (\\n   <div style=\\\"width: 800px; margin: 15% auto;\\\">\\n      <div style=\\\"width: 300px;\\\">\\n        <svg xmlns=\\\"http:\\/\\/www.w3.org\\/2000\\/svg\\\" viewBox=\\\"0 0 150 42\\\"><path d=\\\"M60.2 14.4v27h-3.8v-27h-6.7v-3.3h17.1v3.3h-6.6zm20.2 12.9v14h-3.9v-14l-7.7-16.2h4.1l5.7 12.2 5.7-12.2h3.9l-7.8 16.2zm19.5 2.6h-3.6v11.4h-3.8V11.1s3.7-.3 7.3-.3c6.6 0 8.5 4.1 8.5 9.4 0 6.5-2.3 9.7-8.4 9.7m.4-16c-2.4 0-4.1.3-4.1.3v12.6h4.1c2.4 0 4.1-1.6 4.1-6.3 0-4.4-1-6.6-4.1-6.6m21.5 27.7c-7.1 0-9-5.2-9-15.8 0-10.2 1.9-15.1 9-15.1s9 4.9 9 15.1c.1 10.6-1.8 15.8-9 15.8m0-27.7c-3.9 0-5.2 2.6-5.2 12.1 0 9.3 1.3 12.4 5.2 12.4 3.9 0 5.2-3.1 5.2-12.4 0-9.4-1.3-12.1-5.2-12.1m19.9 27.7c-2.1 0-5.3-.6-5.7-.7v-3.1c1 .2 3.7.7 5.6.7 2.2 0 3.6-1.9 3.6-5.2 0-3.9-.6-6-3.7-6H138V24h3.1c3.5 0 3.7-3.6 3.7-5.3 0-3.4-1.1-4.8-3.2-4.8-1.9 0-4.1.5-5.3.7v-3.2c.5-.1 3-.7 5.2-.7 4.4 0 7 1.9 7 8.3 0 2.9-1 5.5-3.3 6.3 2.6.2 3.8 3.1 3.8 7.3 0 6.6-2.5 9-7.3 9\\\"\\/><path fill=\\\"#FF8700\\\" d=\\\"M31.7 28.8c-.6.2-1.1.2-1.7.2-5.2 0-12.9-18.2-12.9-24.3 0-2.2.5-3 1.3-3.6C12 1.9 4.3 4.2 1.9 7.2 1.3 8 1 9.1 1 10.6c0 9.5 10.1 31 17.3 31 3.3 0 8.8-5.4 13.4-12.8M28.4.5c6.6 0 13.2 1.1 13.2 4.8 0 7.6-4.8 16.7-7.2 16.7-4.4 0-9.9-12.1-9.9-18.2C24.5 1 25.6.5 28.4.5\\\"\\/><\\/svg>\\n      <\\/div>\\n      <h4 style=\\\"font-family: sans-serif;\\\">Welcome to a default website made with <a href=\\\"https:\\/\\/typo3.org\\\">TYPO3<\\/a><\\/h4>\\n   <\\/div>\\n)\\npage.100 = CONTENT\\npage.100 {\\n    table = tt_content\\n    select {\\n        orderBy = sorting\\n        where = {#colPos}=0\\n    }\\n}\\n\",\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/\",\"description\":\"This is an Empty Site Package TypoScript template.\\n\\nFor each website you need a TypoScript template on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject\\/Configuration\\/TypoScript\\/setup.typoscript\'\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value (\\r\\n   <div style=\\\"width: 800px; margin: 15% auto;\\\">\\r\\n      <div style=\\\"width: 300px;\\\">\\r\\n        <svg xmlns=\\\"http:\\/\\/www.w3.org\\/2000\\/svg\\\" viewBox=\\\"0 0 150 42\\\"><path d=\\\"M60.2 14.4v27h-3.8v-27h-6.7v-3.3h17.1v3.3h-6.6zm20.2 12.9v14h-3.9v-14l-7.7-16.2h4.1l5.7 12.2 5.7-12.2h3.9l-7.8 16.2zm19.5 2.6h-3.6v11.4h-3.8V11.1s3.7-.3 7.3-.3c6.6 0 8.5 4.1 8.5 9.4 0 6.5-2.3 9.7-8.4 9.7m.4-16c-2.4 0-4.1.3-4.1.3v12.6h4.1c2.4 0 4.1-1.6 4.1-6.3 0-4.4-1-6.6-4.1-6.6m21.5 27.7c-7.1 0-9-5.2-9-15.8 0-10.2 1.9-15.1 9-15.1s9 4.9 9 15.1c.1 10.6-1.8 15.8-9 15.8m0-27.7c-3.9 0-5.2 2.6-5.2 12.1 0 9.3 1.3 12.4 5.2 12.4 3.9 0 5.2-3.1 5.2-12.4 0-9.4-1.3-12.1-5.2-12.1m19.9 27.7c-2.1 0-5.3-.6-5.7-.7v-3.1c1 .2 3.7.7 5.6.7 2.2 0 3.6-1.9 3.6-5.2 0-3.9-.6-6-3.7-6H138V24h3.1c3.5 0 3.7-3.6 3.7-5.3 0-3.4-1.1-4.8-3.2-4.8-1.9 0-4.1.5-5.3.7v-3.2c.5-.1 3-.7 5.2-.7 4.4 0 7 1.9 7 8.3 0 2.9-1 5.5-3.3 6.3 2.6.2 3.8 3.1 3.8 7.3 0 6.6-2.5 9-7.3 9\\\"\\/><path fill=\\\"#FF8700\\\" d=\\\"M31.7 28.8c-.6.2-1.1.2-1.7.2-5.2 0-12.9-18.2-12.9-24.3 0-2.2.5-3 1.3-3.6C12 1.9 4.3 4.2 1.9 7.2 1.3 8 1 9.1 1 10.6c0 9.5 10.1 31 17.3 31 3.3 0 8.8-5.4 13.4-12.8M28.4.5c6.6 0 13.2 1.1 13.2 4.8 0 7.6-4.8 16.7-7.2 16.7-4.4 0-9.9-12.1-9.9-18.2C24.5 1 25.6.5 28.4.5\\\"\\/><\\/svg>\\r\\n      <\\/div>\\r\\n      <h4 style=\\\"font-family: sans-serif;\\\">Welcome to a default website made with <a href=\\\"https:\\/\\/typo3.org\\\">TYPO3<\\/a><\\/h4>\\r\\n   <\\/div>\\r\\n)\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\",\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:gameskey\\/Configuration\\/TypoScript\",\"description\":\"This is an Empty Site Package TypoScript template.\\r\\n\\r\\nFor each website you need a TypoScript template on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject\\/Configuration\\/TypoScript\\/setup.typoscript\'\"}}',0,'0400$753392a0b1b5f724ae3fdbbfa22d30a4:35af6288617af54964e77af08c30949a'),(6,1710178457,1,'BE',1,0,1,'tt_content','{\"uid\":1,\"rowDescription\":\"\",\"pid\":2,\"tstamp\":1710178457,\"crdate\":1710178457,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"list\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":\"\",\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"gameskey_gamesfrontkey\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"tx_impexp_origuid\":0}',0,'0400$61f979c59efef0bfc7819f94b8a82547:7fa2c035f26826fe83eeecaaeddc4d40'),(7,1710178489,1,'BE',1,0,1,'tx_gameskey_domain_model_games','{\"uid\":1,\"pid\":3,\"tstamp\":1710178489,\"crdate\":1710178489,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"GTA5\",\"description\":\"das hier ist ein einfacher test :)\"}',0,'0400$65b232f0e490bab9ce2ff628b3b94fe9:3dcc1e1eab4ad0d5d6909c677837c865'),(8,1710178522,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value (\\r\\n   <div style=\\\"width: 800px; margin: 15% auto;\\\">\\r\\n      <div style=\\\"width: 300px;\\\">\\r\\n        <svg xmlns=\\\"http:\\/\\/www.w3.org\\/2000\\/svg\\\" viewBox=\\\"0 0 150 42\\\"><path d=\\\"M60.2 14.4v27h-3.8v-27h-6.7v-3.3h17.1v3.3h-6.6zm20.2 12.9v14h-3.9v-14l-7.7-16.2h4.1l5.7 12.2 5.7-12.2h3.9l-7.8 16.2zm19.5 2.6h-3.6v11.4h-3.8V11.1s3.7-.3 7.3-.3c6.6 0 8.5 4.1 8.5 9.4 0 6.5-2.3 9.7-8.4 9.7m.4-16c-2.4 0-4.1.3-4.1.3v12.6h4.1c2.4 0 4.1-1.6 4.1-6.3 0-4.4-1-6.6-4.1-6.6m21.5 27.7c-7.1 0-9-5.2-9-15.8 0-10.2 1.9-15.1 9-15.1s9 4.9 9 15.1c.1 10.6-1.8 15.8-9 15.8m0-27.7c-3.9 0-5.2 2.6-5.2 12.1 0 9.3 1.3 12.4 5.2 12.4 3.9 0 5.2-3.1 5.2-12.4 0-9.4-1.3-12.1-5.2-12.1m19.9 27.7c-2.1 0-5.3-.6-5.7-.7v-3.1c1 .2 3.7.7 5.6.7 2.2 0 3.6-1.9 3.6-5.2 0-3.9-.6-6-3.7-6H138V24h3.1c3.5 0 3.7-3.6 3.7-5.3 0-3.4-1.1-4.8-3.2-4.8-1.9 0-4.1.5-5.3.7v-3.2c.5-.1 3-.7 5.2-.7 4.4 0 7 1.9 7 8.3 0 2.9-1 5.5-3.3 6.3 2.6.2 3.8 3.1 3.8 7.3 0 6.6-2.5 9-7.3 9\\\"\\/><path fill=\\\"#FF8700\\\" d=\\\"M31.7 28.8c-.6.2-1.1.2-1.7.2-5.2 0-12.9-18.2-12.9-24.3 0-2.2.5-3 1.3-3.6C12 1.9 4.3 4.2 1.9 7.2 1.3 8 1 9.1 1 10.6c0 9.5 10.1 31 17.3 31 3.3 0 8.8-5.4 13.4-12.8M28.4.5c6.6 0 13.2 1.1 13.2 4.8 0 7.6-4.8 16.7-7.2 16.7-4.4 0-9.9-12.1-9.9-18.2C24.5 1 25.6.5 28.4.5\\\"\\/><\\/svg>\\r\\n      <\\/div>\\r\\n      <h4 style=\\\"font-family: sans-serif;\\\">Welcome to a default website made with <a href=\\\"https:\\/\\/typo3.org\\\">TYPO3<\\/a><\\/h4>\\r\\n   <\\/div>\\r\\n)\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\n\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"}}',0,'0400$5573c33317661acb788e745f4a838f5c:35af6288617af54964e77af08c30949a'),(9,1710178951,4,'BE',1,0,1,'tx_gameskey_domain_model_games',NULL,0,'0400$da5cfd202c804f36e4575c239cb96be9:3dcc1e1eab4ad0d5d6909c677837c865'),(10,1710178961,1,'BE',1,0,2,'tx_gameskey_domain_model_games','{\"uid\":2,\"pid\":3,\"tstamp\":1710178961,\"crdate\":1710178961,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"Test\",\"description\":\"GG\"}',0,'0400$f2e2a9edbf6f8968bf997a8de37d9255:d2a2b0be4ef7069fe79b8b2a50e8555f'),(11,1710229392,1,'BE',1,0,3,'tx_gameskey_domain_model_games','{\"uid\":3,\"pid\":3,\"tstamp\":1710229392,\"crdate\":1710229392,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"number\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"Spiel 2\",\"description\":\"Spiel2 Desc\",\"number\":0}',0,'0400$923b373f143ca385cf1011d40e9f5aa1:a5cfdbe87324eaae9899232461d43f98'),(12,1710236753,4,'BE',1,0,2,'tx_gameskey_domain_model_games',NULL,0,'0400$36ad121069f149018d2449a73eb792d8:d2a2b0be4ef7069fe79b8b2a50e8555f'),(13,1710236756,4,'BE',1,0,3,'tx_gameskey_domain_model_games',NULL,0,'0400$a20cfc190b467affd63b1fc74850da1b:a5cfdbe87324eaae9899232461d43f98'),(14,1710236947,1,'BE',1,0,4,'tx_gameskey_domain_model_games','{\"uid\":4,\"pid\":3,\"tstamp\":1710236947,\"crdate\":1710236947,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"GTA5\",\"description\":\"GTA Description\",\"zzz_deleted_number\":0,\"rating\":0,\"rating_sum\":0,\"image\":0,\"rel_date\":\"2013-09-17 10:46:00\",\"rating_count\":0}',0,'0400$4c1e36a4f50972b327f0e87227f0e309:40d43293baefabedac7b7089abf8a546'),(15,1710236947,1,'BE',1,0,1,'sys_file_reference','{\"uid\":1,\"pid\":3,\"tstamp\":1710236947,\"crdate\":1710236947,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":1,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$4c1e36a4f50972b327f0e87227f0e309:4cf496f597e7b095ce8b755e6cec3c0c'),(16,1710243924,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\r\\n\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\npage.includeCSS\\u00a0{\\r\\n  bootstrapCSS = https:\\/\\/cdn.jsdelivr.net\\/npm\\/bootstrap@5.3.3\\/dist\\/css\\/bootstrap.min.css\\r\\n}\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"}}',0,'0400$e7913add887c8d52625f252099027733:35af6288617af54964e77af08c30949a'),(17,1710243968,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\r\\npage.includeCSS\\u00a0{\\r\\n  bootstrapCSS = https:\\/\\/cdn.jsdelivr.net\\/npm\\/bootstrap@5.3.3\\/dist\\/css\\/bootstrap.min.css\\r\\n}\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\npage.includeCSS\\u00a0{\\r\\n  css = https:\\/\\/cdn.jsdelivr.net\\/npm\\/bootstrap@5.3.3\\/dist\\/css\\/bootstrap.min.css\\r\\n}\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"}}',0,'0400$d35f9bca4ba8f9f03f0a46cefa614aa0:35af6288617af54964e77af08c30949a'),(18,1710243989,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\r\\npage.includeCSS\\u00a0{\\r\\n  css = https:\\/\\/cdn.jsdelivr.net\\/npm\\/bootstrap@5.3.3\\/dist\\/css\\/bootstrap.min.css\\r\\n}\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"}}',0,'0400$6d9a6a8e434f9592e1af48a9413b4974:35af6288617af54964e77af08c30949a'),(19,1710244020,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\npage.includeCSS {\\r\\n  bs = https:\\/\\/cdn.jsdelivr.net\\/npm\\/bootstrap@5.3.3\\/dist\\/css\\/bootstrap.min.css\\r\\n}\\r\\n\\r\\npage.100 = CONTENT\\r\\npage.100 {\\r\\n    table = tt_content\\r\\n    select {\\r\\n        orderBy = sorting\\r\\n        where = {#colPos}=0\\r\\n    }\\r\\n}\\r\\n\"}}',0,'0400$bdf4c0c7a7cef1b534dbae66110d5fda:35af6288617af54964e77af08c30949a'),(20,1710252706,2,'BE',1,0,4,'tx_gameskey_domain_model_games','{\"oldRecord\":{\"description\":\"GTA Description\",\"rating\":3.7377049180328,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"description\":\"\\\"Grand Theft Auto V\\\" (GTA 5) ist ein actiongeladenes Open-World-Abenteuer, entwickelt von Rockstar North. Es ist der f\\u00fcnfzehnte Teil in der Grand Theft Auto-Serie und entf\\u00fchrt die Spieler erneut in die fiktive Welt von Los Santos und Blaine County, inspiriert von Los Angeles und S\\u00fcdkalifornien. Ver\\u00f6ffentlicht im September 2013, setzt das Spiel neue Ma\\u00dfst\\u00e4be in Bezug auf Grafik, Spielmechanik und Erz\\u00e4hlweise.\\r\\n\\r\\nIn der Rolle von drei Protagonisten \\u2013 dem ehemaligen Bankr\\u00e4uber Michael De Santa, dem Stra\\u00dfenganoven Franklin Clinton und dem psychopathischen Trevor Philips \\u2013 erleben die Spieler eine ineinander verflochtene Geschichte voller Heists, Verrat und Suche nach dem eigenen Schnitt in einer gnadenlosen Welt. Jeder Charakter hat seine eigene Pers\\u00f6nlichkeit, Hintergrundgeschichte und spezielle F\\u00e4higkeiten, die w\\u00e4hrend des Spiels eingesetzt werden k\\u00f6nnen.\\r\\n\\r\\nNeben der fesselnden Einzelspielerkampagne bietet GTA 5 auch \\\"GTA Online\\\", ein dynamisches und st\\u00e4ndig wachsendes Universum f\\u00fcr bis zu 30 Spieler, das alle Gameplay-Upgrades und Inhalte seit dem Start des Spiels umfasst. Spieler k\\u00f6nnen alleine oder mit Freunden spielen, um ihre ultimative kriminelle Imperium aufzubauen, indem sie an Heists teilnehmen, Unternehmen gr\\u00fcnden und gegen andere Spieler antreten, um der dominanteste Verbrecherboss zu werden.\\r\\n\\r\\nGTA 5 wurde f\\u00fcr seine offene Welt, das Design, die Erz\\u00e4hlweise und die Freiheit, die es den Spielern bietet, gelobt. Mit einer Mischung aus Story-Missionen, Nebenaktivit\\u00e4ten und der M\\u00f6glichkeit, einfach die riesige Welt zu erkunden, setzt GTA 5 weiterhin Standards f\\u00fcr das Genre und bleibt eines der beliebtesten Videospiele weltweit\\u200b\\u200b.\",\"rating\":\"3.74\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$7bbf9bc7257a9f83bf13ecdd1b29f767:40d43293baefabedac7b7089abf8a546'),(21,1710252706,2,'BE',1,0,1,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$7bbf9bc7257a9f83bf13ecdd1b29f767:4cf496f597e7b095ce8b755e6cec3c0c'),(22,1710254482,1,'BE',1,0,5,'tx_gameskey_domain_model_games','{\"uid\":5,\"pid\":3,\"tstamp\":1710254482,\"crdate\":1710254482,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"GTA V\",\"description\":\"\\\"Grand Theft Auto V\\\" (GTA 5) ist ein actiongeladenes Open-World-Abenteuer, entwickelt von Rockstar North. Es ist der f\\u00fcnfzehnte Teil in der Grand Theft Auto-Serie und entf\\u00fchrt die Spieler erneut in die fiktive Welt von Los Santos und Blaine County, inspiriert von Los Angeles und S\\u00fcdkalifornien. Ver\\u00f6ffentlicht im September 2013, setzt das Spiel neue Ma\\u00dfst\\u00e4be in Bezug auf Grafik, Spielmechanik und Erz\\u00e4hlweise.\\r\\n\\r\\nIn der Rolle von drei Protagonisten \\u2013 dem ehemaligen Bankr\\u00e4uber Michael De Santa, dem Stra\\u00dfenganoven Franklin Clinton und dem psychopathischen Trevor Philips \\u2013 erleben die Spieler eine ineinander verflochtene Geschichte voller Heists, Verrat und Suche nach dem eigenen Schnitt in einer gnadenlosen Welt. Jeder Charakter hat seine eigene Pers\\u00f6nlichkeit, Hintergrundgeschichte und spezielle F\\u00e4higkeiten, die w\\u00e4hrend des Spiels eingesetzt werden k\\u00f6nnen.\\r\\n\\r\\nNeben der fesselnden Einzelspielerkampagne bietet GTA 5 auch \\\"GTA Online\\\", ein dynamisches und st\\u00e4ndig wachsendes Universum f\\u00fcr bis zu 30 Spieler, das alle Gameplay-Upgrades und Inhalte seit dem Start des Spiels umfasst. Spieler k\\u00f6nnen alleine oder mit Freunden spielen, um ihre ultimative kriminelle Imperium aufzubauen, indem sie an Heists teilnehmen, Unternehmen gr\\u00fcnden und gegen andere Spieler antreten, um der dominanteste Verbrecherboss zu werden.\\r\\n\\r\\nGTA 5 wurde f\\u00fcr seine offene Welt, das Design, die Erz\\u00e4hlweise und die Freiheit, die es den Spielern bietet, gelobt. Mit einer Mischung aus Story-Missionen, Nebenaktivit\\u00e4ten und der M\\u00f6glichkeit, einfach die riesige Welt zu erkunden, setzt GTA 5 weiterhin Standards f\\u00fcr das Genre und bleibt eines der beliebtesten Videospiele weltweit\\u200b\\u200b.\",\"zzz_deleted_number\":0,\"rating\":0,\"rating_sum\":0,\"image\":0,\"rel_date\":\"2013-09-13\",\"rating_count\":0,\"fsk18\":1,\"action\":1,\"multiplayer\":1,\"singleplayer\":1}',0,'0400$5d95e8f6f5681925712df97ac9735b96:1c799bbb68528358cb8a61e081d1ee4b'),(23,1710254482,1,'BE',1,0,2,'sys_file_reference','{\"uid\":2,\"pid\":3,\"tstamp\":1710254482,\"crdate\":1710254482,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":1,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$5d95e8f6f5681925712df97ac9735b96:814fc0f720dfab882655a795e23a5b66'),(24,1710254491,2,'BE',1,0,5,'tx_gameskey_domain_model_games','{\"oldRecord\":{\"rating\":0,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"rating\":\"0.00\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$9201838c222e755b6201e0adde8e04ab:1c799bbb68528358cb8a61e081d1ee4b'),(25,1710254491,2,'BE',1,0,2,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$9201838c222e755b6201e0adde8e04ab:814fc0f720dfab882655a795e23a5b66'),(26,1710254497,4,'BE',1,0,1,'sys_file_reference',NULL,0,'0400$020c668788c3124922dbc2925e53e64c:4cf496f597e7b095ce8b755e6cec3c0c'),(27,1710254497,4,'BE',1,0,4,'tx_gameskey_domain_model_games',NULL,0,'0400$020c668788c3124922dbc2925e53e64c:40d43293baefabedac7b7089abf8a546'),(28,1710255371,1,'BE',1,0,6,'tx_gameskey_domain_model_games','{\"uid\":6,\"pid\":3,\"tstamp\":1710255371,\"crdate\":1710255371,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"Helldivers 2\",\"description\":\"\\\"Helldivers 2\\\" ist eine Fortsetzung des beliebten kooperativen Third-Person-Shooters von Arrowhead Game Studios, die f\\u00fcr die PlayStation 5 und PC erschienen ist. In diesem intensiven, auf Kooperation ausgelegten Spiel nehmen die Spieler erneut die Rolle von galaktischen Friedensh\\u00fctern und Soldaten im Namen von Super Earth an, diesmal jedoch mit deutlich verbesserten F\\u00e4higkeiten und Ausr\\u00fcstungen. Das Spiel f\\u00fchrt die Spieler in epische Schlachten gegen au\\u00dferirdische Bedrohungen, wobei sie Zugang zu einem umfangreichen Arsenal an Waffen und strategischen Hilfsmitteln wie Luftschl\\u00e4gen, Gesch\\u00fctzt\\u00fcrmen, Minen und mehr haben.\\r\\n\\r\\nDie Entwickler von Arrowhead haben den Fokus darauf gelegt, die spannende und angespannte Kampferfahrung aus dem ersten Spiel zu \\u00fcbernehmen und in \\\"Helldivers 2\\\" weiter zu vergr\\u00f6\\u00dfern. Mit der Einf\\u00fchrung einer neuen Third-Person-Perspektive soll das Gameplay noch aufregender gestaltet werden, wobei der Spa\\u00df und die Spannung bei jeder Designentscheidung im Vordergrund stehen. Ein zentrales Element des Spiels ist die Kooperation zwischen den Spielern, die als Team gegen die au\\u00dferirdischen Bedrohungen vorgehen m\\u00fcssen, um den Frieden und die Freiheit von Super Earth zu verteidigen.\\r\\n\\r\\n\\\"Helldivers 2\\\" hat seit seiner Ver\\u00f6ffentlichung allgemein positive Kritiken erhalten, wobei die Spieler insbesondere das erstklassige Schussgef\\u00fchl und die epische, oft kinoreife Erfahrung loben. Trotz einiger Probleme mit der Spielervermittlung und Abst\\u00fcrzen zu Beginn wurde das Spiel f\\u00fcr sein kooperatives Gameplay und die satirische Darstellung einer milit\\u00e4rischen Regime, vergleichbar mit dem Film \\\"Starship Troopers\\\", gesch\\u00e4tzt. Das Spiel konnte innerhalb kurzer Zeit nach Ver\\u00f6ffentlichung etwa 1 Million Einheiten verkaufen und wurde zum gr\\u00f6\\u00dften Launch eines von PlayStation Studios ver\\u00f6ffentlichten Spiels auf dem PC\\u200b\\u200b\\u200b\\u200b\\u200b\\u200b.\",\"zzz_deleted_number\":0,\"rating\":0,\"rating_sum\":0,\"image\":0,\"rel_date\":\"2024-02-08\",\"rating_count\":0,\"fsk18\":0,\"action\":1,\"multiplayer\":1,\"singleplayer\":0}',0,'0400$3b8024afad4fa5a3d0efc4bd53c3a122:d4da1c966ec34963af59c9307ca49bc3'),(29,1710255371,1,'BE',1,0,3,'sys_file_reference','{\"uid\":3,\"pid\":3,\"tstamp\":1710255371,\"crdate\":1710255371,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":2,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$3b8024afad4fa5a3d0efc4bd53c3a122:d2c609347a4764200256b39b9425159a'),(30,1710321147,2,'BE',1,0,5,'tx_gameskey_domain_model_games','{\"oldRecord\":{\"singleplayer\":1},\"newRecord\":{\"singleplayer\":\"0\"}}',0,'0400$d2abc9fe86ae2215aeb4e87474b99ed9:1c799bbb68528358cb8a61e081d1ee4b'),(31,1710321153,2,'BE',1,0,6,'tx_gameskey_domain_model_games','{\"oldRecord\":{\"rating\":0,\"singleplayer\":0,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"rating\":\"0.00\",\"singleplayer\":\"1\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$565254437a7006277cd3194681def79d:d4da1c966ec34963af59c9307ca49bc3'),(32,1710321153,2,'BE',1,0,3,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$565254437a7006277cd3194681def79d:d2c609347a4764200256b39b9425159a'),(33,1710323722,2,'BE',1,0,6,'tx_gameskey_domain_model_games','{\"oldRecord\":{\"rating\":0,\"singleplayer\":1},\"newRecord\":{\"rating\":\"0.00\",\"singleplayer\":\"0\"}}',0,'0400$4bb0d1c29260dd31a7b33b95aefccab3:d4da1c966ec34963af59c9307ca49bc3'),(34,1710323731,2,'BE',1,0,5,'tx_gameskey_domain_model_games','{\"oldRecord\":{\"singleplayer\":0},\"newRecord\":{\"singleplayer\":\"1\"}}',0,'0400$a2c3a424eadba0a670e55841c3433d81:1c799bbb68528358cb8a61e081d1ee4b'),(35,1710331079,1,'BE',1,0,7,'tx_gameskey_domain_model_games','{\"uid\":7,\"pid\":3,\"tstamp\":1710331079,\"crdate\":1710331079,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"Minecraft\",\"description\":\"\\\"Minecraft\\\" ist ein Sandbox-Computerspiel, das urspr\\u00fcnglich von Markus Persson entwickelt und sp\\u00e4ter von Microsoft \\u00fcbernommen wurde. Es bietet eine offene Welt, die aus w\\u00fcrfelf\\u00f6rmigen Bl\\u00f6cken besteht, die in einem 3D-Raster angeordnet sind. Spieler k\\u00f6nnen diese Bl\\u00f6cke abbauen, sammeln und an anderer Stelle platzieren, um Konstruktionen, Werkzeuge, Waffen und R\\u00fcstungen zu erstellen. Das Spiel beinhaltet ein Crafting-System, durch das Spieler verschiedene Gegenst\\u00e4nde herstellen k\\u00f6nnen, indem sie Materialien nach bestimmten Mustern im Herstellungsfeld anordnen.\\r\\n\\r\\nMinecraft verf\\u00fcgt \\u00fcber ein Inventarsystem, in dem Spieler Gegenst\\u00e4nde sammeln und tragen k\\u00f6nnen. Das Spiel ignoriert teilweise die Gesetze der Physik, wodurch Bl\\u00f6cke in der Luft schweben k\\u00f6nnen und nur Wasser und Lava als Fl\\u00fcssigkeiten gelten, die flie\\u00dfen und eine Quelle haben. Redstone kann f\\u00fcr den Bau von Schaltkreisen genutzt werden, um Signale zu \\u00fcbertragen und Mechanismen wie T\\u00fcren zu betreiben.\\r\\n\\r\\nDie Welt in Minecraft ist in verschiedene Biome unterteilt, darunter Berge, W\\u00e4lder, W\\u00fcsten, Meere und mehr, und weist einen Tag-Nacht-Zyklus auf. Spieler begegnen verschiedenen NPCs, darunter friedliche Tiere und feindliche Kreaturen wie Zombies und Skelette. Minecraft bietet drei Dimensionen: die Oberwelt, den Nether und das Ende, wobei jede ihre eigenen Besonderheiten hat.\\r\\n\\r\\nEs gibt f\\u00fcnf Spielmodi: \\u00dcberlebensmodus, Hardcoremodus, Kreativmodus, Abenteuermodus und Zuschauermodus, die sich in Schwierigkeitsgraden und Spielzielen unterscheiden. Der Hardcore-Modus ist eine Variante des \\u00dcberlebensmodus mit h\\u00f6herem Schwierigkeitsgrad.\\r\\n\\r\\nMinecraft unterst\\u00fctzt sowohl den Einzel- als auch den Mehrspielermodus und ist auf einer Vielzahl von Plattformen verf\\u00fcgbar, darunter PC, Konsolen und mobile Ger\\u00e4te\\u200b\\u200b\\u200b\\u200b.\",\"zzz_deleted_number\":0,\"rating\":0,\"rating_sum\":0,\"image\":0,\"rel_date\":\"2011-11-18\",\"rating_count\":0,\"fsk18\":0,\"action\":0,\"multiplayer\":1,\"singleplayer\":1}',0,'0400$03b9eff167345260dcbcd7303187f8fc:625eb20183c292db1bbeb10598d0d59e'),(36,1710331079,1,'BE',1,0,4,'sys_file_reference','{\"uid\":4,\"pid\":3,\"tstamp\":1710331079,\"crdate\":1710331079,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":5,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$03b9eff167345260dcbcd7303187f8fc:cea5fcd7b97871880cfe3717d6b52ef4'),(37,1710331181,1,'BE',1,0,8,'tx_gameskey_domain_model_games','{\"uid\":8,\"pid\":3,\"tstamp\":1710331181,\"crdate\":1710331181,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"Need For Speed Carbon\",\"description\":\"\\\"Need for Speed: Carbon\\\" setzt die Geschichte direkt nach den Ereignissen von \\\"Need for Speed: Most Wanted\\\" fort und f\\u00fchrt die Spieler nach Palmont City. In diesem Teil der Serie steht die Eroberung verschiedener Stadtteile im Vordergrund, die von rivalisierenden Stra\\u00dfenrennerteams kontrolliert werden. Die Spieler m\\u00fcssen ihre F\\u00e4higkeiten unter Beweis stellen, indem sie in unterschiedlichen Rennen gegen diese Teams antreten, um letztendlich die Kontrolle \\u00fcber die gesamte Stadt zu erlangen. Ein besonderes Feature von Carbon sind die Canyon-Duelle, eine Hommage an das japanische T\\u014dge-Rennen, die auf kurvenreichen Bergstra\\u00dfen au\\u00dferhalb der Hauptspielumgebung stattfinden. Diese Herausforderungen erfordern besondere Vorsicht, da die Gefahr besteht, durch zerbrechliche Leitplanken zu st\\u00fcrzen und das Rennen zu verlieren.\\r\\n\\r\\nDas Spiel bietet eine Vielzahl lizenzierter Fahrzeuge, die in drei verschiedene Kategorien eingeteilt sind: Exoten, Tuner und Muscle Cars. Jede Kategorie bietet einzigartige Fahreigenschaften und Herausforderungen. Au\\u00dferdem verf\\u00fcgt das Spiel \\u00fcber ein detailliertes Anpassungssystem, das es den Spielern erm\\u00f6glicht, ihre Fahrzeuge sowohl in Leistung als auch in Aussehen zu modifizieren, einschlie\\u00dflich der Nutzung von Autosculpt f\\u00fcr die visuelle Anpassung. \\\"Need for Speed: Carbon\\\" f\\u00fchrt au\\u00dferdem Wingmen ein, computergesteuerte Teammitglieder, die den Spieler w\\u00e4hrend der Rennen unterst\\u00fctzen und in drei Verhaltenstypen unterteilt sind: Blocker, Drafter und Scouts.\\r\\n\\r\\nObwohl das Spiel insgesamt positive Kritiken erhielt, wurde es f\\u00fcr bestimmte Gameplay-Elemente kritisiert, insbesondere f\\u00fcr die geringere Betonung von Polizeiverfolgungen im Vergleich zu seinem Vorg\\u00e4nger. Die Spieler k\\u00f6nnen die spannende Geschichte und die dynamische Welt von \\\"Need for Speed: Carbon\\\" erkunden, die durch interessante Charaktere und Wendungen angereichert wird, obwohl die Geschichte manchmal als etwas verwirrend empfunden werden kann\\u200b\\u200b\\u200b\\u200b.\",\"zzz_deleted_number\":0,\"rating\":0,\"rating_sum\":0,\"image\":0,\"rel_date\":\"2006-10-31\",\"rating_count\":0,\"fsk18\":0,\"action\":1,\"multiplayer\":0,\"singleplayer\":1}',0,'0400$4cf5480c08b8d2735992da82971ab5e3:0e9d160edd028873c2e1caaffae4618a'),(38,1710331181,1,'BE',1,0,5,'sys_file_reference','{\"uid\":5,\"pid\":3,\"tstamp\":1710331181,\"crdate\":1710331181,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":3,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$4cf5480c08b8d2735992da82971ab5e3:5f15a1453f67b933ed3314381f5d67e4'),(39,1710331525,2,'BE',1,0,8,'tx_gameskey_domain_model_games','{\"oldRecord\":{\"rating\":0,\"l10n_diffsource\":\"{\\\"l10n_parent\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"rating\":\"0.00\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"rating\\\":\\\"\\\",\\\"rating_count\\\":\\\"\\\",\\\"rating_sum\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"rel_date\\\":\\\"\\\",\\\"fsk18\\\":\\\"\\\",\\\"action\\\":\\\"\\\",\\\"multiplayer\\\":\\\"\\\",\\\"singleplayer\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\"}\"}}',0,'0400$9dd93f8eb6ea7db12d121449c325872c:0e9d160edd028873c2e1caaffae4618a'),(40,1710331525,2,'BE',1,0,5,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$9dd93f8eb6ea7db12d121449c325872c:5f15a1453f67b933ed3314381f5d67e4');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) NOT NULL DEFAULT '',
  `flag` varchar(20) NOT NULL DEFAULT '',
  `language_isocode` varchar(2) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES (36,1,1710331525,'tx_gameskey_domain_model_games',8,0,'admin',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=474 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1,0,1710177433,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.11','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(2,0,1710178221,1,1,2,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:5:\"Games\";i:1;s:7:\"pages:2\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW_1','',0,'','info',NULL,NULL),(3,0,1710178225,1,1,3,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:8:\"addgames\";i:1;s:7:\"pages:3\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW_1','',0,'','info',NULL,NULL),(4,0,1710178228,1,2,2,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:5:\"Games\";i:1;s:7:\"pages:2\";s:7:\"history\";s:1:\"3\";}',2,0,'','',0,'','info',NULL,NULL),(5,0,1710178230,1,2,3,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:8:\"addgames\";i:1;s:7:\"pages:3\";s:7:\"history\";s:1:\"4\";}',3,0,'','',0,'','info',NULL,NULL),(6,0,1710178428,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:25:\"Main TypoScript Rendering\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:1:\"5\";}',1,0,'','',0,'','info',NULL,NULL),(7,0,1710178457,1,1,1,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:10:\"[No title]\";i:1;s:12:\"tt_content:1\";i:2;s:5:\"Games\";i:3;i:2;}',2,0,'NEW65ef40892afe2194313262','',0,'','info',NULL,NULL),(8,0,1710178489,1,1,1,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:4:\"GTA5\";i:1;s:32:\"tx_gameskey_domain_model_games:1\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65ef40a4d4d4b230614104','',0,'','info',NULL,NULL),(9,0,1710178522,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:25:\"Main TypoScript Rendering\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:1:\"8\";}',1,0,'','',0,'','info',NULL,NULL),(10,0,1710178566,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(13,0,1710178788,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(14,0,1710178829,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(16,0,1710178951,1,3,1,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.18.0.11','a:4:{i:0;s:4:\"GTA5\";i:1;s:32:\"tx_gameskey_domain_model_games:1\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'','',0,'','info',NULL,NULL),(17,0,1710178961,1,1,2,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:4:\"Test\";i:1;s:32:\"tx_gameskey_domain_model_games:2\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65ef428c79580957887721','',0,'','info',NULL,NULL),(18,0,1710178971,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(19,0,1710179186,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(23,0,1710179888,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(24,0,1710180061,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(25,0,1710180137,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(26,0,1710180138,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(31,0,1710183657,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(32,0,1710183745,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(33,0,1710183770,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(34,0,1710183851,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(35,0,1710183871,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(39,0,1710184784,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(43,0,1710184803,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(44,0,1710185126,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(55,0,1710185622,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(56,0,1710185681,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(61,0,1710185738,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(62,0,1710185741,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(63,0,1710185744,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(65,0,1710185809,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(70,0,1710185839,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(72,0,1710185892,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(78,0,1710186022,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(81,0,1710186077,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(84,0,1710186114,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(86,0,1710186167,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(88,0,1710186224,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(90,0,1710186472,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(91,0,1710186550,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(93,0,1710228399,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.11','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(94,0,1710228402,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(98,0,1710228885,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(106,0,1710229298,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(107,0,1710229300,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(109,0,1710229392,1,1,3,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:7:\"Spiel 2\";i:1;s:32:\"tx_gameskey_domain_model_games:3\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f007871fe56476847958','',0,'','info',NULL,NULL),(118,0,1710230198,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(121,0,1710230252,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(124,0,1710230504,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(125,0,1710230694,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(126,0,1710231572,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(127,0,1710231787,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(129,0,1710231827,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(130,0,1710231904,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(132,0,1710231929,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(135,0,1710232227,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(137,0,1710232627,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(139,0,1710232939,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(140,0,1710232980,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(141,0,1710233084,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(142,0,1710233107,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(143,0,1710233120,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(144,0,1710233143,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(145,0,1710233191,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(147,0,1710233220,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(148,0,1710233255,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(149,0,1710233282,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(150,0,1710233303,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(151,0,1710233312,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(152,0,1710233458,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(156,0,1710233716,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(158,0,1710233766,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(159,0,1710233875,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(160,0,1710233935,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(161,0,1710233970,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(162,0,1710233985,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(163,0,1710234046,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(164,0,1710234141,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(165,0,1710234425,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(166,0,1710235265,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(167,0,1710236173,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(172,0,1710236709,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(173,0,1710236753,1,3,2,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.18.0.11','a:4:{i:0;s:16:\"Spiel 2 Neue GGG\";i:1;s:32:\"tx_gameskey_domain_model_games:2\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'','',0,'','info',NULL,NULL),(174,0,1710236756,1,3,3,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.18.0.11','a:4:{i:0;s:16:\"Spiel 2 Neue GGG\";i:1;s:32:\"tx_gameskey_domain_model_games:3\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'','',0,'','info',NULL,NULL),(175,0,1710236947,1,1,4,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:4:\"GTA5\";i:1;s:32:\"tx_gameskey_domain_model_games:4\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f02458ec676447722640','',0,'','info',NULL,NULL),(176,0,1710236947,1,1,1,'sys_file_reference',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:22:\"Grand_Theft_Auto_V.png\";i:1;s:20:\"sys_file_reference:1\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f0250dc220a099842159','',0,'','info',NULL,NULL),(177,0,1710236947,1,2,4,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:4:\"GTA5\";i:1;s:32:\"tx_gameskey_domain_model_games:4\";s:7:\"history\";i:0;}',3,0,'','',0,'','info',NULL,NULL),(178,0,1710238825,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(179,0,1710239274,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(180,0,1710239326,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(181,0,1710239343,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(185,0,1710243924,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:25:\"Main TypoScript Rendering\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:2:\"16\";}',1,0,'','',0,'','info',NULL,NULL),(186,0,1710243931,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(187,0,1710243968,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:25:\"Main TypoScript Rendering\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:2:\"17\";}',1,0,'','',0,'','info',NULL,NULL),(188,0,1710243970,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(189,0,1710243989,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:25:\"Main TypoScript Rendering\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:2:\"18\";}',1,0,'','',0,'','info',NULL,NULL),(190,0,1710244020,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:25:\"Main TypoScript Rendering\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:2:\"19\";}',1,0,'','',0,'','info',NULL,NULL),(191,0,1710244021,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(192,0,1710244173,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(208,0,1710245758,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(209,0,1710252706,1,2,4,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:4:\"GTA5\";i:1;s:32:\"tx_gameskey_domain_model_games:4\";s:7:\"history\";s:2:\"20\";}',3,0,'','',0,'','info',NULL,NULL),(210,0,1710252706,1,2,1,'sys_file_reference',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:22:\"Grand_Theft_Auto_V.png\";i:1;s:20:\"sys_file_reference:1\";s:7:\"history\";s:2:\"21\";}',3,0,'','',0,'','info',NULL,NULL),(213,0,1710253308,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(214,0,1710253418,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(215,0,1710253420,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(216,0,1710253511,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(217,0,1710253713,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(218,0,1710254398,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(219,0,1710254482,1,1,5,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:5:\"GTA V\";i:1;s:32:\"tx_gameskey_domain_model_games:5\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f06963b4e8d957158719','',0,'','info',NULL,NULL),(220,0,1710254482,1,1,2,'sys_file_reference',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:22:\"Grand_Theft_Auto_V.png\";i:1;s:20:\"sys_file_reference:2\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f0698684896480311755','',0,'','info',NULL,NULL),(221,0,1710254482,1,2,5,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:5:\"GTA V\";i:1;s:32:\"tx_gameskey_domain_model_games:5\";s:7:\"history\";i:0;}',3,0,'','',0,'','info',NULL,NULL),(222,0,1710254491,1,2,5,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:5:\"GTA V\";i:1;s:32:\"tx_gameskey_domain_model_games:5\";s:7:\"history\";s:2:\"24\";}',3,0,'','',0,'','info',NULL,NULL),(223,0,1710254491,1,2,2,'sys_file_reference',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:22:\"Grand_Theft_Auto_V.png\";i:1;s:20:\"sys_file_reference:2\";s:7:\"history\";s:2:\"25\";}',3,0,'','',0,'','info',NULL,NULL),(224,0,1710254497,1,3,1,'sys_file_reference',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.18.0.11','a:4:{i:0;s:22:\"Grand_Theft_Auto_V.png\";i:1;s:20:\"sys_file_reference:1\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'','',0,'','info',NULL,NULL),(225,0,1710254497,1,3,4,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,'content',0,'172.18.0.11','a:4:{i:0;s:4:\"GTA5\";i:1;s:32:\"tx_gameskey_domain_model_games:4\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'','',0,'','info',NULL,NULL),(226,0,1710254501,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(227,0,1710254503,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(228,0,1710254620,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(229,0,1710254895,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(230,0,1710255371,1,1,6,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:12:\"Helldivers 2\";i:1;s:32:\"tx_gameskey_domain_model_games:6\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f06bae73e8e099304581','',0,'','info',NULL,NULL),(231,0,1710255371,1,1,3,'sys_file_reference',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:16:\"Helldivers-2.jpg\";i:1;s:20:\"sys_file_reference:3\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f06c020e499046757530','',0,'','info',NULL,NULL),(232,0,1710255371,1,2,6,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:12:\"Helldivers 2\";i:1;s:32:\"tx_gameskey_domain_model_games:6\";s:7:\"history\";i:0;}',3,0,'','',0,'','info',NULL,NULL),(233,0,1710255402,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(234,0,1710255466,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(235,0,1710256319,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(237,0,1710257131,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(247,0,1710257479,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(250,0,1710258315,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(251,0,1710258534,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(252,0,1710258832,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(253,0,1710259295,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(254,0,1710259357,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(255,0,1710259398,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(259,0,1710314633,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.11','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'','info',NULL,NULL),(260,0,1710314636,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(263,0,1710314787,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(264,0,1710314815,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(265,0,1710314842,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(266,0,1710314868,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(267,0,1710315217,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(268,0,1710315300,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(269,0,1710315369,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(270,0,1710315402,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(273,0,1710315590,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(276,0,1710316289,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(283,0,1710316310,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(288,0,1710316839,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(289,0,1710317363,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(290,0,1710317549,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(292,0,1710318028,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(295,0,1710318058,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(303,0,1710319889,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(304,0,1710319899,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(305,0,1710319926,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(306,0,1710319946,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(307,0,1710319993,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(308,0,1710320010,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(317,0,1710321147,1,2,5,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:5:\"GTA V\";i:1;s:32:\"tx_gameskey_domain_model_games:5\";s:7:\"history\";s:2:\"30\";}',3,0,'','',0,'','info',NULL,NULL),(318,0,1710321153,1,2,6,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:12:\"Helldivers 2\";i:1;s:32:\"tx_gameskey_domain_model_games:6\";s:7:\"history\";s:2:\"31\";}',3,0,'','',0,'','info',NULL,NULL),(319,0,1710321153,1,2,3,'sys_file_reference',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:16:\"Helldivers-2.jpg\";i:1;s:20:\"sys_file_reference:3\";s:7:\"history\";s:2:\"32\";}',3,0,'','',0,'','info',NULL,NULL),(320,0,1710321168,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(321,0,1710322425,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(322,0,1710322501,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(324,0,1710322567,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(326,0,1710322597,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(328,0,1710322638,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(330,0,1710322717,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(337,0,1710323295,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(338,0,1710323722,1,2,6,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:12:\"Helldivers 2\";i:1;s:32:\"tx_gameskey_domain_model_games:6\";s:7:\"history\";s:2:\"33\";}',3,0,'','',0,'','info',NULL,NULL),(339,0,1710323731,1,2,5,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:5:\"GTA V\";i:1;s:32:\"tx_gameskey_domain_model_games:5\";s:7:\"history\";s:2:\"34\";}',3,0,'','',0,'','info',NULL,NULL),(340,0,1710323833,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:5:\"pages\";}',-1,0,'','',0,'','info',NULL,NULL),(341,0,1710323834,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(344,0,1710323883,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(347,0,1710323902,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(354,0,1710323950,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(367,0,1710324238,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(383,0,1710330562,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(388,0,1710330712,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(398,0,1710331079,1,1,7,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:9:\"Minecraft\";i:1;s:32:\"tx_gameskey_domain_model_games:7\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f1940ba8460460618983','',0,'','info',NULL,NULL),(399,0,1710331079,1,1,4,'sys_file_reference',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:13:\"Minecraft.jpg\";i:1;s:20:\"sys_file_reference:4\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f1948f327b4921678899','',0,'','info',NULL,NULL),(400,0,1710331079,1,2,7,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:9:\"Minecraft\";i:1;s:32:\"tx_gameskey_domain_model_games:7\";s:7:\"history\";i:0;}',3,0,'','',0,'','info',NULL,NULL),(401,0,1710331181,1,1,8,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:21:\"Need For Speed Carbon\";i:1;s:32:\"tx_gameskey_domain_model_games:8\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f194cc6ce5a366290866','',0,'','info',NULL,NULL),(402,0,1710331181,1,1,5,'sys_file_reference',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,'content',10,'172.18.0.11','a:4:{i:0;s:14:\"NFS_Carbon.jpg\";i:1;s:20:\"sys_file_reference:5\";i:2;s:8:\"addgames\";i:3;i:3;}',3,0,'NEW65f195173be28528672204','',0,'','info',NULL,NULL),(403,0,1710331181,1,2,8,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:21:\"Need For Speed Carbon\";i:1;s:32:\"tx_gameskey_domain_model_games:8\";s:7:\"history\";i:0;}',3,0,'','',0,'','info',NULL,NULL),(404,0,1710331197,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(405,0,1710331207,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(406,0,1710331279,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(407,0,1710331284,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(408,0,1710331386,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(409,0,1710331394,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(410,0,1710331406,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(411,0,1710331440,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(412,0,1710331472,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(413,0,1710331481,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(414,0,1710331483,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(415,0,1710331502,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(416,0,1710331525,1,2,8,'tx_gameskey_domain_model_games',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:21:\"Need For Speed Carbon\";i:1;s:32:\"tx_gameskey_domain_model_games:8\";s:7:\"history\";s:2:\"39\";}',3,0,'','',0,'','info',NULL,NULL),(417,0,1710331525,1,2,5,'sys_file_reference',0,0,'Record \'%s\' (%s) was updated. (Online).',1,'content',10,'172.18.0.11','a:3:{i:0;s:14:\"NFS_Carbon.jpg\";i:1;s:20:\"sys_file_reference:5\";s:7:\"history\";s:2:\"40\";}',3,0,'','',0,'','info',NULL,NULL),(418,0,1710331528,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(419,0,1710331548,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(420,0,1710331560,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(421,0,1710331566,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(422,0,1710331567,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(423,0,1710331571,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(424,0,1710331576,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(425,0,1710331593,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(426,0,1710331594,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(427,0,1710331599,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(428,0,1710331602,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(429,0,1710331608,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(430,0,1710331621,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(431,0,1710331622,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(432,0,1710331633,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(433,0,1710331634,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(434,0,1710331678,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(435,0,1710331681,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(436,0,1710331685,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(437,0,1710331734,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(438,0,1710331751,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(439,0,1710331884,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(440,0,1710331888,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(441,0,1710331892,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(442,0,1710331894,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(443,0,1710331896,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(444,0,1710331931,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(445,0,1710331933,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(446,0,1710332099,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(447,0,1710332101,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(448,0,1710332101,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined property: Bennet\\Gameskey\\Domain\\Repository\\GamesRepository::$findAll() in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 176',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(449,0,1710332101,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: foreach() argument must be of type array|object, null given in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 178',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(450,0,1710332112,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(451,0,1710332112,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1233180480: The method \"findAll()\" is not supported by the repository. | TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Exception\\UnsupportedMethodException thrown in file /var/www/html/public/typo3/sysext/extbase/Classes/Persistence/Repository.php in line 256. Requested URL: https://gameratingv2.ddev.site/games?tx_gameskey_gamesfrontkey%%5Baction%%5D=search&tx_gameskey_gamesfrontkey%%5Bcontroller%%5D=Games&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B0%%5D=5&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B1%%5D=6&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B2%%5D=7&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B3%%5D=8&cHash=f73943a2ab5d75e5270f4eda882d74ee',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','error',NULL,NULL),(452,0,1710332116,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(453,0,1710332151,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(454,0,1710332152,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(455,0,1710332153,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1472074485: Unknown column \'tx_gameskey_domain_model_games.$arg\' in \'where clause\' | TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Storage\\Exception\\SqlErrorException thrown in file /var/www/html/public/typo3/sysext/extbase/Classes/Persistence/Generic/Storage/Typo3DbBackend.php in line 249. Requested URL: https://gameratingv2.ddev.site/games?tx_gameskey_gamesfrontkey%%5Baction%%5D=search&tx_gameskey_gamesfrontkey%%5Barg%%5D=findSingleplayerGames&tx_gameskey_gamesfrontkey%%5Bcontroller%%5D=Games&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B0%%5D=5&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B1%%5D=6&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B2%%5D=7&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B3%%5D=8&cHash=c263789846090c6a1f4420337903b4de',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','error',NULL,NULL),(456,0,1710332154,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1472074485: Unknown column \'tx_gameskey_domain_model_games.$arg\' in \'where clause\' | TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Storage\\Exception\\SqlErrorException thrown in file /var/www/html/public/typo3/sysext/extbase/Classes/Persistence/Generic/Storage/Typo3DbBackend.php in line 249. Requested URL: https://gameratingv2.ddev.site/games?tx_gameskey_gamesfrontkey%%5Baction%%5D=search&tx_gameskey_gamesfrontkey%%5Barg%%5D=findSingleplayerGames&tx_gameskey_gamesfrontkey%%5Bcontroller%%5D=Games&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B0%%5D=5&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B1%%5D=6&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B2%%5D=7&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B3%%5D=8&cHash=c263789846090c6a1f4420337903b4de',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','error',NULL,NULL),(457,0,1710332155,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1472074485: Unknown column \'tx_gameskey_domain_model_games.$arg\' in \'where clause\' | TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Storage\\Exception\\SqlErrorException thrown in file /var/www/html/public/typo3/sysext/extbase/Classes/Persistence/Generic/Storage/Typo3DbBackend.php in line 249. Requested URL: https://gameratingv2.ddev.site/games?tx_gameskey_gamesfrontkey%%5Baction%%5D=search&tx_gameskey_gamesfrontkey%%5Barg%%5D=findSingleplayerGames&tx_gameskey_gamesfrontkey%%5Bcontroller%%5D=Games&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B0%%5D=5&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B1%%5D=6&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B2%%5D=7&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B3%%5D=8&cHash=c263789846090c6a1f4420337903b4de',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','error',NULL,NULL),(458,0,1710332155,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1472074485: Unknown column \'tx_gameskey_domain_model_games.$arg\' in \'where clause\' | TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Storage\\Exception\\SqlErrorException thrown in file /var/www/html/public/typo3/sysext/extbase/Classes/Persistence/Generic/Storage/Typo3DbBackend.php in line 249. Requested URL: https://gameratingv2.ddev.site/games?tx_gameskey_gamesfrontkey%%5Baction%%5D=search&tx_gameskey_gamesfrontkey%%5Barg%%5D=findSingleplayerGames&tx_gameskey_gamesfrontkey%%5Bcontroller%%5D=Games&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B0%%5D=5&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B1%%5D=6&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B2%%5D=7&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B3%%5D=8&cHash=c263789846090c6a1f4420337903b4de',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','error',NULL,NULL),(459,0,1710332170,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(460,0,1710332172,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(461,0,1710332193,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(462,0,1710332196,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(463,0,1710332197,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1233180480: The method \"fsk18\" is not supported by the repository. | TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Exception\\UnsupportedMethodException thrown in file /var/www/html/public/typo3/sysext/extbase/Classes/Persistence/Repository.php in line 256. Requested URL: https://gameratingv2.ddev.site/games?tx_gameskey_gamesfrontkey%%5Baction%%5D=search&tx_gameskey_gamesfrontkey%%5Barg%%5D=findMultiplayerGames&tx_gameskey_gamesfrontkey%%5Bcontroller%%5D=Games&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B0%%5D=5&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B1%%5D=6&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B2%%5D=7&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B3%%5D=8&cHash=57cfaecff7d216a37a6577dbf3f70ae9',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','error',NULL,NULL),(464,0,1710332198,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1233180480: The method \"fsk18\" is not supported by the repository. | TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Exception\\UnsupportedMethodException thrown in file /var/www/html/public/typo3/sysext/extbase/Classes/Persistence/Repository.php in line 256. Requested URL: https://gameratingv2.ddev.site/games?tx_gameskey_gamesfrontkey%%5Baction%%5D=search&tx_gameskey_gamesfrontkey%%5Barg%%5D=findSingleplayerGames&tx_gameskey_gamesfrontkey%%5Bcontroller%%5D=Games&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B0%%5D=5&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B1%%5D=6&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B2%%5D=7&tx_gameskey_gamesfrontkey%%5Bgames%%5D%%5B3%%5D=8&cHash=c263789846090c6a1f4420337903b4de',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','error',NULL,NULL),(465,0,1710332211,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,'default',0,'172.18.0.11','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'','info',NULL,NULL),(466,0,1710332222,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(467,0,1710332318,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(468,0,1710332403,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(469,0,1710344656,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(470,0,1710344700,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(471,0,1710345749,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(472,0,1710345749,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL),(473,0,1710345815,1,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"arg\" in /var/www/html/packages/gameskey/Classes/Controller/GamesController.php line 169',5,'php',0,'172.18.0.11','',-1,0,'','',0,'','warning',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('1c9b8784c1518ef7b22704c4fc698ca9','sys_file',2,'storage','','','',0,0,'sys_file_storage',1,''),('24d47b29aa969cf4db8635e76dd1c386','sys_file',3,'storage','','','',0,0,'sys_file_storage',1,''),('39433ea4a82060704109046e4828d3c8','sys_file',1,'storage','','','',0,0,'sys_file_storage',1,''),('71153deb49aa4037245642a09ea67aa3','sys_template',1,'config','','url','2',-1,0,'_STRING',0,'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css'),('791d3f9d43dcbfa78cd49dd8258caa09','sys_file',5,'storage','','','',0,0,'sys_file_storage',1,''),('7be91dc5af89aa55622503e0babff75d','tx_gameskey_domain_model_games',8,'image','','','',0,0,'sys_file_reference',5,''),('84243fc2bc0280435873cdc95543e3d8','tx_gameskey_domain_model_games',5,'image','','','',0,0,'sys_file_reference',2,''),('84ff82a67cd289d0e2439163972de22d','sys_file_reference',2,'uid_local','','','',0,0,'sys_file',1,''),('9aa735b34f972455c212c0a5340dfc55','tx_gameskey_domain_model_games',6,'image','','','',0,0,'sys_file_reference',3,''),('bab37143de5339e474516691bf0c5857','sys_file',4,'storage','','','',0,0,'sys_file_storage',1,''),('ec24aa755716879c31a61cc9e34f17d7','sys_file_reference',5,'uid_local','','','',0,0,'sys_file',3,''),('ec47fb71dfcb8576a659a7a64f8e9a65','tx_gameskey_domain_model_games',7,'image','','','',0,0,'sys_file_reference',4,''),('f6d51b6462745ab29b986de8799f8202','sys_file_reference',3,'uid_local','','','',0,0,'sys_file',2,''),('f8b59591c9f0c90f80045c88a7938159','sys_file_reference',4,'uid_local','','','',0,0,'sys_file',5,''),('fe80a6589cac9798aa13ab5e0192cb56','sys_file',1,'metadata','','','',0,0,'sys_file_metadata',1,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ShortcutRecordsMigration','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CollectionsExtractionUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),(9,'installUpdate','TYPO3\\CMS\\FrontendLogin\\Updates\\MigrateFeloginPlugins','i:1;'),(10,'installUpdateRows','rowUpdatersDone','a:4:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceVersionRecordsMigration\";i:1;s:66:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L18nDiffsourceToJsonMigration\";i:2;s:77:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceMovePlaceholderRemovalMigration\";i:3;s:76:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceNewPlaceholderRemovalMigration\";}'),(11,'core','formProtectionSessionToken:1','s:64:\"be606bd982a30a6672e035b58440c9e179819d398822faa4bb8dca9e0284b30b\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1710244020,1710177431,1,0,0,0,0,0,'This is an Empty Site Package TypoScript template.\r\n\r\nFor each website you need a TypoScript template on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject/Configuration/TypoScript/setup.typoscript\'',0,0,0,0,0,'Main TypoScript Rendering',1,1,'EXT:fluid_styled_content/Configuration/TypoScript/,EXT:fluid_styled_content/Configuration/TypoScript/Styling/,EXT:gameskey/Configuration/TypoScript','','page = PAGE\r\npage.includeCSS {\r\n  bs = https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\r\n}\r\n\r\npage.100 = CONTENT\r\npage.100 {\r\n    table = tt_content\r\n    select {\r\n        orderBy = sorting\r\n        where = {#colPos}=0\r\n    }\r\n}\r\n',NULL,0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',2,1710178457,1710178457,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','gameskey_gamesfrontkey',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_gameskey_domain_model_games`
--

DROP TABLE IF EXISTS `tx_gameskey_domain_model_games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_gameskey_domain_model_games` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `zzz_deleted_number` int(11) NOT NULL DEFAULT 0,
  `rating` double NOT NULL DEFAULT 0,
  `rating_sum` int(11) NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `rel_date` date DEFAULT NULL,
  `rating_count` int(11) NOT NULL DEFAULT 0,
  `fsk18` smallint(5) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `multiplayer` smallint(5) unsigned NOT NULL DEFAULT 0,
  `singleplayer` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_gameskey_domain_model_games`
--

LOCK TABLES `tx_gameskey_domain_model_games` WRITE;
/*!40000 ALTER TABLE `tx_gameskey_domain_model_games` DISABLE KEYS */;
INSERT INTO `tx_gameskey_domain_model_games` VALUES (1,3,1710178951,1710178489,1,1,0,0,0,0,0,NULL,'{\"l10n_parent\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"title\":\"\",\"description\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\"}',0,0,0,0,'GTA5','das hier ist ein einfacher test :)',0,0,0,0,NULL,0,0,0,0,0),(2,3,1710236753,1710178961,1,1,0,0,0,0,0,NULL,'{\"l10n_parent\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"title\":\"\",\"description\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\"}',0,0,0,0,'Spiel 2 Neue GGG','GG',0,0,0,0,NULL,0,0,0,0,0),(3,3,1710236756,1710229392,1,1,0,0,0,0,0,NULL,'{\"l10n_parent\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"title\":\"\",\"description\":\"\",\"number\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\"}',0,0,0,0,'Spiel 2 Neue GGG','Spiel2 Desc',0,0,0,0,NULL,0,0,0,0,0),(4,3,1710254497,1710236947,1,1,0,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"rating\":\"\",\"rating_count\":\"\",\"rating_sum\":\"\",\"image\":\"\",\"rel_date\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\"}',0,0,0,0,'GTA5','\"Grand Theft Auto V\" (GTA 5) ist ein actiongeladenes Open-World-Abenteuer, entwickelt von Rockstar North. Es ist der fünfzehnte Teil in der Grand Theft Auto-Serie und entführt die Spieler erneut in die fiktive Welt von Los Santos und Blaine County, inspiriert von Los Angeles und Südkalifornien. Veröffentlicht im September 2013, setzt das Spiel neue Maßstäbe in Bezug auf Grafik, Spielmechanik und Erzählweise.\r\n\r\nIn der Rolle von drei Protagonisten – dem ehemaligen Bankräuber Michael De Santa, dem Straßenganoven Franklin Clinton und dem psychopathischen Trevor Philips – erleben die Spieler eine ineinander verflochtene Geschichte voller Heists, Verrat und Suche nach dem eigenen Schnitt in einer gnadenlosen Welt. Jeder Charakter hat seine eigene Persönlichkeit, Hintergrundgeschichte und spezielle Fähigkeiten, die während des Spiels eingesetzt werden können.\r\n\r\nNeben der fesselnden Einzelspielerkampagne bietet GTA 5 auch \"GTA Online\", ein dynamisches und ständig wachsendes Universum für bis zu 30 Spieler, das alle Gameplay-Upgrades und Inhalte seit dem Start des Spiels umfasst. Spieler können alleine oder mit Freunden spielen, um ihre ultimative kriminelle Imperium aufzubauen, indem sie an Heists teilnehmen, Unternehmen gründen und gegen andere Spieler antreten, um der dominanteste Verbrecherboss zu werden.\r\n\r\nGTA 5 wurde für seine offene Welt, das Design, die Erzählweise und die Freiheit, die es den Spielern bietet, gelobt. Mit einer Mischung aus Story-Missionen, Nebenaktivitäten und der Möglichkeit, einfach die riesige Welt zu erkunden, setzt GTA 5 weiterhin Standards für das Genre und bleibt eines der beliebtesten Videospiele weltweit​​.',0,3.83,92,1,'2013-09-17',24,0,0,0,0),(5,3,1710331598,1710254482,1,0,0,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"rating\":\"\",\"rating_count\":\"\",\"rating_sum\":\"\",\"image\":\"\",\"rel_date\":\"\",\"fsk18\":\"\",\"action\":\"\",\"multiplayer\":\"\",\"singleplayer\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\"}',0,0,0,0,'GTA V','\"Grand Theft Auto V\" (GTA 5) ist ein actiongeladenes Open-World-Abenteuer, entwickelt von Rockstar North. Es ist der fünfzehnte Teil in der Grand Theft Auto-Serie und entführt die Spieler erneut in die fiktive Welt von Los Santos und Blaine County, inspiriert von Los Angeles und Südkalifornien. Veröffentlicht im September 2013, setzt das Spiel neue Maßstäbe in Bezug auf Grafik, Spielmechanik und Erzählweise.\r\n\r\nIn der Rolle von drei Protagonisten – dem ehemaligen Bankräuber Michael De Santa, dem Straßenganoven Franklin Clinton und dem psychopathischen Trevor Philips – erleben die Spieler eine ineinander verflochtene Geschichte voller Heists, Verrat und Suche nach dem eigenen Schnitt in einer gnadenlosen Welt. Jeder Charakter hat seine eigene Persönlichkeit, Hintergrundgeschichte und spezielle Fähigkeiten, die während des Spiels eingesetzt werden können.\r\n\r\nNeben der fesselnden Einzelspielerkampagne bietet GTA 5 auch \"GTA Online\", ein dynamisches und ständig wachsendes Universum für bis zu 30 Spieler, das alle Gameplay-Upgrades und Inhalte seit dem Start des Spiels umfasst. Spieler können alleine oder mit Freunden spielen, um ihre ultimative kriminelle Imperium aufzubauen, indem sie an Heists teilnehmen, Unternehmen gründen und gegen andere Spieler antreten, um der dominanteste Verbrecherboss zu werden.\r\n\r\nGTA 5 wurde für seine offene Welt, das Design, die Erzählweise und die Freiheit, die es den Spielern bietet, gelobt. Mit einer Mischung aus Story-Missionen, Nebenaktivitäten und der Möglichkeit, einfach die riesige Welt zu erkunden, setzt GTA 5 weiterhin Standards für das Genre und bleibt eines der beliebtesten Videospiele weltweit​​.',0,5,5,1,'2013-09-13',1,1,1,1,1),(6,3,1710344697,1710255371,1,0,0,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"rating\":\"\",\"rating_count\":\"\",\"rating_sum\":\"\",\"image\":\"\",\"rel_date\":\"\",\"fsk18\":\"\",\"action\":\"\",\"multiplayer\":\"\",\"singleplayer\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\"}',0,0,0,0,'Helldivers 2','\"Helldivers 2\" ist eine Fortsetzung des beliebten kooperativen Third-Person-Shooters von Arrowhead Game Studios, die für die PlayStation 5 und PC erschienen ist. In diesem intensiven, auf Kooperation ausgelegten Spiel nehmen die Spieler erneut die Rolle von galaktischen Friedenshütern und Soldaten im Namen von Super Earth an, diesmal jedoch mit deutlich verbesserten Fähigkeiten und Ausrüstungen. Das Spiel führt die Spieler in epische Schlachten gegen außerirdische Bedrohungen, wobei sie Zugang zu einem umfangreichen Arsenal an Waffen und strategischen Hilfsmitteln wie Luftschlägen, Geschütztürmen, Minen und mehr haben.\r\n\r\nDie Entwickler von Arrowhead haben den Fokus darauf gelegt, die spannende und angespannte Kampferfahrung aus dem ersten Spiel zu übernehmen und in \"Helldivers 2\" weiter zu vergrößern. Mit der Einführung einer neuen Third-Person-Perspektive soll das Gameplay noch aufregender gestaltet werden, wobei der Spaß und die Spannung bei jeder Designentscheidung im Vordergrund stehen. Ein zentrales Element des Spiels ist die Kooperation zwischen den Spielern, die als Team gegen die außerirdischen Bedrohungen vorgehen müssen, um den Frieden und die Freiheit von Super Earth zu verteidigen.\r\n\r\n\"Helldivers 2\" hat seit seiner Veröffentlichung allgemein positive Kritiken erhalten, wobei die Spieler insbesondere das erstklassige Schussgefühl und die epische, oft kinoreife Erfahrung loben. Trotz einiger Probleme mit der Spielervermittlung und Abstürzen zu Beginn wurde das Spiel für sein kooperatives Gameplay und die satirische Darstellung einer militärischen Regime, vergleichbar mit dem Film \"Starship Troopers\", geschätzt. Das Spiel konnte innerhalb kurzer Zeit nach Veröffentlichung etwa 1 Million Einheiten verkaufen und wurde zum größten Launch eines von PlayStation Studios veröffentlichten Spiels auf dem PC​​​​​​.',0,2.5,5,1,'2024-02-08',2,0,1,1,0),(7,3,1710331891,1710331079,1,0,0,0,0,0,0,NULL,'{\"l10n_parent\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"title\":\"\",\"description\":\"\",\"rating_count\":\"\",\"rating_sum\":\"\",\"fsk18\":\"\",\"action\":\"\",\"multiplayer\":\"\",\"singleplayer\":\"\",\"rating\":\"\",\"image\":\"\",\"rel_date\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\"}',0,0,0,0,'Minecraft','\"Minecraft\" ist ein Sandbox-Computerspiel, das ursprünglich von Markus Persson entwickelt und später von Microsoft übernommen wurde. Es bietet eine offene Welt, die aus würfelförmigen Blöcken besteht, die in einem 3D-Raster angeordnet sind. Spieler können diese Blöcke abbauen, sammeln und an anderer Stelle platzieren, um Konstruktionen, Werkzeuge, Waffen und Rüstungen zu erstellen. Das Spiel beinhaltet ein Crafting-System, durch das Spieler verschiedene Gegenstände herstellen können, indem sie Materialien nach bestimmten Mustern im Herstellungsfeld anordnen.\r\n\r\nMinecraft verfügt über ein Inventarsystem, in dem Spieler Gegenstände sammeln und tragen können. Das Spiel ignoriert teilweise die Gesetze der Physik, wodurch Blöcke in der Luft schweben können und nur Wasser und Lava als Flüssigkeiten gelten, die fließen und eine Quelle haben. Redstone kann für den Bau von Schaltkreisen genutzt werden, um Signale zu übertragen und Mechanismen wie Türen zu betreiben.\r\n\r\nDie Welt in Minecraft ist in verschiedene Biome unterteilt, darunter Berge, Wälder, Wüsten, Meere und mehr, und weist einen Tag-Nacht-Zyklus auf. Spieler begegnen verschiedenen NPCs, darunter friedliche Tiere und feindliche Kreaturen wie Zombies und Skelette. Minecraft bietet drei Dimensionen: die Oberwelt, den Nether und das Ende, wobei jede ihre eigenen Besonderheiten hat.\r\n\r\nEs gibt fünf Spielmodi: Überlebensmodus, Hardcoremodus, Kreativmodus, Abenteuermodus und Zuschauermodus, die sich in Schwierigkeitsgraden und Spielzielen unterscheiden. Der Hardcore-Modus ist eine Variante des Überlebensmodus mit höherem Schwierigkeitsgrad.\r\n\r\nMinecraft unterstützt sowohl den Einzel- als auch den Mehrspielermodus und ist auf einer Vielzahl von Plattformen verfügbar, darunter PC, Konsolen und mobile Geräte​​​​.',0,5,25,1,'2011-11-18',5,0,0,1,1),(8,3,1710331601,1710331181,1,0,0,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"rating\":\"\",\"rating_count\":\"\",\"rating_sum\":\"\",\"image\":\"\",\"rel_date\":\"\",\"fsk18\":\"\",\"action\":\"\",\"multiplayer\":\"\",\"singleplayer\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\"}',0,0,0,0,'Need For Speed Carbon','\"Need for Speed: Carbon\" setzt die Geschichte direkt nach den Ereignissen von \"Need for Speed: Most Wanted\" fort und führt die Spieler nach Palmont City. In diesem Teil der Serie steht die Eroberung verschiedener Stadtteile im Vordergrund, die von rivalisierenden Straßenrennerteams kontrolliert werden. Die Spieler müssen ihre Fähigkeiten unter Beweis stellen, indem sie in unterschiedlichen Rennen gegen diese Teams antreten, um letztendlich die Kontrolle über die gesamte Stadt zu erlangen. Ein besonderes Feature von Carbon sind die Canyon-Duelle, eine Hommage an das japanische Tōge-Rennen, die auf kurvenreichen Bergstraßen außerhalb der Hauptspielumgebung stattfinden. Diese Herausforderungen erfordern besondere Vorsicht, da die Gefahr besteht, durch zerbrechliche Leitplanken zu stürzen und das Rennen zu verlieren.\r\n\r\nDas Spiel bietet eine Vielzahl lizenzierter Fahrzeuge, die in drei verschiedene Kategorien eingeteilt sind: Exoten, Tuner und Muscle Cars. Jede Kategorie bietet einzigartige Fahreigenschaften und Herausforderungen. Außerdem verfügt das Spiel über ein detailliertes Anpassungssystem, das es den Spielern ermöglicht, ihre Fahrzeuge sowohl in Leistung als auch in Aussehen zu modifizieren, einschließlich der Nutzung von Autosculpt für die visuelle Anpassung. \"Need for Speed: Carbon\" führt außerdem Wingmen ein, computergesteuerte Teammitglieder, die den Spieler während der Rennen unterstützen und in drei Verhaltenstypen unterteilt sind: Blocker, Drafter und Scouts.\r\n\r\nObwohl das Spiel insgesamt positive Kritiken erhielt, wurde es für bestimmte Gameplay-Elemente kritisiert, insbesondere für die geringere Betonung von Polizeiverfolgungen im Vergleich zu seinem Vorgänger. Die Spieler können die spannende Geschichte und die dynamische Welt von \"Need for Speed: Carbon\" erkunden, die durch interessante Charaktere und Wendungen angereichert wird, obwohl die Geschichte manchmal als etwas verwirrend empfunden werden kann​​​​.',0,5,5,1,'2006-10-31',1,0,1,0,1);
/*!40000 ALTER TABLE `tx_gameskey_domain_model_games` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-13 16:29:29
